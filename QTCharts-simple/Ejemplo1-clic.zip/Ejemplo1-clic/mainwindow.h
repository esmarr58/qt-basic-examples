#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void agregarDato();

private:
    Ui::MainWindow *ui;

    QChart* grafico = nullptr;
    QLineSeries* serie = nullptr;
    QValueAxis* ejeX = nullptr;
    QValueAxis* ejeY = nullptr;
    int contadorX = 0;   // índice en X para cada punto agregado
};

#endif // MAINWINDOW_H
