#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>
#include <QRandomGenerator>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Crear serie y gráfico
    serie  = new QLineSeries();
    grafico = new QChart();
    grafico->addSeries(serie);
    grafico->setTitle("Gráfica simple con QtCharts");

    // Crear ejes
    ejeX = new QValueAxis();
    ejeY = new QValueAxis();
    ejeX->setTitleText("Muestra");
    ejeY->setTitleText("Valor");
    ejeX->setRange(0, 20);    // ventana visible de 20 puntos
    ejeY->setRange(0, 100);   // datos aleatorios 0..100

    grafico->addAxis(ejeX, Qt::AlignBottom);
    grafico->addAxis(ejeY, Qt::AlignLeft);
    serie->attachAxis(ejeX);
    serie->attachAxis(ejeY);

    // Mostrar en el ChartView del UI
    ui->chartView->setChart(grafico);
    ui->chartView->setRenderHint(QPainter::Antialiasing);

    // Conectar el botón
    connect(ui->btnAgregar, &QPushButton::clicked,
            this, &MainWindow::agregarDato);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::agregarDato()
{
    // Generar valor aleatorio [0, 100)
    const int valor = QRandomGenerator::global()->bounded(100);

    // Agregar punto (x,y)
    serie->append(contadorX, valor);

    // Desplazar ventana del eje X para mostrar los últimos 20 puntos
    if (contadorX > 20) {
        ejeX->setRange(contadorX - 20, contadorX);
    }

    ++contadorX;
}
