#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    manejarPuertosSeriales(ui->comboBox,115200);

    // --- Configuración de los displays ---
    ui->displayTemperatura->setDigitCount(5);   // p.ej. "25.5"
    ui->displayTemperatura->setSegmentStyle(QLCDNumber::Flat);



    ui->displayHumedad->setDigitCount(5);       // p.ej. "65.8"
    ui->displayHumedad->setSegmentStyle(QLCDNumber::Flat);

    ui->lineEdit->setPlaceholderText(
        R"({"sensor":"dht22","pin":4})"
        );

    // Configurar tu combo existente (ajusta el objeto UI si se llama distinto)

    // Conectar tu señal a un slot miembro para manejar cada línea
    connect(this, &MainWindow::serialLineaRecibida,
            this, &MainWindow::onSerialLineaRecibida);

}

MainWindow::~MainWindow()
{
    if (serialActual) {
        if (serialActual->isOpen())
            serialActual->close();
        delete serialActual;
        serialActual = nullptr;
    }
    delete ui;
}


void MainWindow::manejarPuertosSeriales(QComboBox *comboBox, int baud)
{
    if (!comboBox) {
        qWarning() << "Debes pasar un QComboBox válido.";
        return;
    }

    // --- Poblar puertos ---
    auto poblarPuertos = [comboBox]() {
        comboBox->blockSignals(true);
        comboBox->clear();
        comboBox->addItem("Seleccionar puerto", QVariant());

        const QList<QSerialPortInfo> puertos = QSerialPortInfo::availablePorts();
        for (const QSerialPortInfo &info : puertos) {
            const QString nombre = info.portName();
            const QString desc   = info.description().isEmpty() ? "Sin descripción" : info.description();
            const QString texto  = QString("%1 — %2").arg(nombre, desc);
            comboBox->addItem(texto, nombre);
        }
        comboBox->blockSignals(false);
    };
    poblarPuertos();

    QObject::disconnect(comboBox, nullptr, this, nullptr);

    QObject::connect(comboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
                     this,
                     [this, comboBox, baud](int idx) {
                         if (idx <= 0) {
                             if (serialActual && serialActual->isOpen()) {
                                 QString nombre = serialActual->portName();
                                 qDebug() << "Cerrando puerto:" << nombre;
                                 serialActual->close();
                                 QMessageBox::information(this, "Desconectado",
                                                          "Se ha desconectado el puerto " + nombre);
                             }
                             if (serialActual) {
                                 serialActual->deleteLater();
                                 serialActual = nullptr;
                             }
                             return;
                         }

                         const QString nombrePuerto = comboBox->currentData().toString();

                         if (serialActual && serialActual->isOpen()) {
                             qDebug() << "Cerrando puerto previo:" << serialActual->portName();
                             serialActual->close();
                             serialActual->deleteLater();
                             serialActual = nullptr;
                         }

                         serialActual = new QSerialPort(this);
                         serialActual->setPortName(nombrePuerto);
                         serialActual->setBaudRate(baud);
                         serialActual->setDataBits(QSerialPort::Data8);
                         serialActual->setParity(QSerialPort::NoParity);
                         serialActual->setStopBits(QSerialPort::OneStop);
                         serialActual->setFlowControl(QSerialPort::NoFlowControl);

                         if (!serialActual->open(QIODevice::ReadWrite)) {
                             qWarning() << "No se pudo abrir" << nombrePuerto << ":" << serialActual->errorString();
                             QMessageBox::warning(this, "Error",
                                                  "No se pudo abrir el puerto " + nombrePuerto + "\n" +
                                                      serialActual->errorString());
                             serialActual->deleteLater();
                             serialActual = nullptr;

                             comboBox->blockSignals(true);
                             comboBox->setCurrentIndex(0);
                             comboBox->blockSignals(false);
                             return;
                         }

                         qDebug() << "Conexión OK en" << nombrePuerto;

                         QMessageBox::information(this, "Conectado",
                                                  "Se ha conectado exitosamente al puerto " + nombrePuerto);

                         connect(serialActual, &QSerialPort::readyRead,
                                 this, &MainWindow::onReadyRead,
                                 Qt::UniqueConnection);
                     });
}


void MainWindow::onReadyRead()
{
    if (!serialActual) return;
    while (serialActual->canReadLine()) {
        const QByteArray datos = serialActual->readLine().trimmed();
        emit serialLineaRecibida(QString::fromUtf8(datos));
    }
}
void MainWindow::onSerialLineaRecibida(const QString &linea)
{
    // Ejemplo de respuesta: {"ok":true,"temp":25.5,"humedad":65.8}
    const QByteArray bytes = linea.toUtf8();
    QJsonParseError perr;
    const QJsonDocument doc = QJsonDocument::fromJson(bytes, &perr);
    if (perr.error != QJsonParseError::NoError || !doc.isObject()) {
        qWarning() << "JSON inválido:" << perr.errorString() << "en" << linea;
        return;
    }

    const QJsonObject obj = doc.object();

    // (Opcional) valida "ok"
    if (obj.contains("ok") && obj.value("ok").isBool() && !obj.value("ok").toBool()) {
        qWarning() << "Mensaje con ok=false";
        return;
    }

    // Lee temp y humedad si existen
    if (obj.contains("temp") && obj.value("temp").isDouble()) {
        const double t = obj.value("temp").toDouble();
        // Muestra con 1 decimal (QLCDNumber acepta QString para controlar decimales)
        ui->displayTemperatura->display(QString::number(t, 'f', 1));
    }

    if (obj.contains("humedad") && obj.value("humedad").isDouble()) {
        const double h = obj.value("humedad").toDouble();
        ui->displayHumedad->display(QString::number(h, 'f', 1));
    }
}

void MainWindow::on_pushButton_clicked()
{
    if (!serialActual || !serialActual->isOpen()) {
        QMessageBox::warning(this, "Error", "No hay ningún puerto abierto.");
        return;
    }

    // Tomar el texto escrito por el usuario (ej: {"sensor":"dht22","pin":4})
    QString jsonStr = ui->lineEdit->text().trimmed();
    if (jsonStr.isEmpty()) {
        QMessageBox::information(this, "Aviso", "Por favor escribe un mensaje JSON.");
        return;
    }

    // Convertir a bytes y agregar un salto de línea
    QByteArray datos = jsonStr.toUtf8() + "\n";

    // Enviar al puerto serial
    qint64 enviados = serialActual->write(datos);

    if (enviados == -1)
        QMessageBox::warning(this, "Error", "No se pudo enviar el mensaje.");
    else
        qDebug() << "JSON enviado:" << jsonStr;
}
