#pragma once
#include <QMainWindow>
#include <QCamera>
#include <QMediaDevices>
#include <QMediaCaptureSession>
#include <QVideoSink>
#include <QThread>
#include <QImage>
#include <atomic>
#include <memory>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <QLabel>
#include <QMessageBox>
#include <QVector>
#include <QPainter>
#include <QJsonObject>
#include "websocketcliente.h"   // <-- agrega
#include <QElapsedTimer>

#include <QRect>

class DetectorSonrisas;   // forward
class DetectorDedos;
class WebSocketCliente;         // <-- forward-declare
class DetectorColores;   // ← no incluyas el .h aquí; lo incluiremos en el .cpp


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class FrameWorker;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    void pedirPermisosCamara();
    void iniciarCamaraSiHayPermiso();

    // Selección de formato 16:9 cercano a 1280x720 o 1920x1080
    static QCameraFormat pickFormat16x9(const QCameraDevice &dev);

private slots:
    void onImageReady(const QImage &img);

    void setStatusOk(const QString &msg);
    void setStatusError(const QString &msg);
    void on_checkBox_clicked();
protected:
    bool eventFilter(QObject* obj, QEvent* event) override;
    void closeEvent(QCloseEvent* e) override;

private:
    Ui::MainWindow *ui = nullptr;
    QLabel *m_statusLbl = nullptr;


    // Cámara y multimedia (SIEMPRE en hilo GUI)
    std::unique_ptr<QCamera>     m_camera;
    std::unique_ptr<QVideoSink>  m_sink;
    QMediaCaptureSession         m_session;

    // Procesamiento en hilo propio
    QThread      m_workerThread;
    FrameWorker* m_worker = nullptr;

    // Control de backpressure
    std::atomic_bool m_busy{false};

    // Última imagen para repintar/resize
    QImage m_lastImg;

    // Para no reconectar múltiples veces el sink
    bool m_sinkConnected = false;

    // en la clase MainWindow (zona private):
    QThread           m_hiloSonrisas;
    DetectorSonrisas* m_detector = nullptr;

    // para dibujar los rectángulos en onImageReady:
    QVector<QRect> m_rectsCaras;
    QVector<QRect> m_rectsSonrisas;
    bool m_hayCara = false;
    bool m_haySonrisa = false;

    QThread         m_hiloDedos;
    DetectorDedos*  m_dedos = nullptr;

    // Para overlay
    int             m_numDedos = 0;
    QVector<QPoint> m_tipsDedos;
    QRect           m_bboxMano;

    // === WebSocket en hilo dedicado ===
    QThread           m_wsThread;     // hilo donde correrá el cliente
    WebSocketCliente* m_ws = nullptr; // instancia que vivirá en m_wsThread
    QString ipESP32 = "esp32-5434e4.local";   // ← pon aquí la IP fija de tu ESP32

    QThread          m_colorThread;     // hilo dedicado
    DetectorColores* m_color = nullptr; // instancia que vivirá en m_colorThread

    // Estado para dibujar y lógica de UI (se actualizarán vía señales/lambdas)
    QImage m_maskColor1;   // máscara binaria 8bpp (Grayscale8) color 1
    QImage m_maskColor2;   // máscara binaria 8bpp (Grayscale8) color 2
    double m_cov1 = 0.0;   // cobertura [0..1] color 1
    double m_cov2 = 0.0;   // cobertura [0..1] color 2
    bool   m_pred1 = false; // color 1 predominante (>= 30%)
    bool   m_pred2 = false; // color 2 predominante (>= 30%)

    // Control de calibración desde UI
    bool m_calibrandoColor = false; // estado del botón "calibrar"
    int  m_colorActivo = 1;         // 1 o 2 (según radioButton / radioButton_2)

    QImage m_lastHSV;    // HSV en QImage::Format_RGB888 (H,S,V en 3 canales)
    double m_colorThresh = 0.15;  // porcentaje mínimo (0.30 = 30%)

    // --- Control de comandos (anti-rebote + rate-limit + histéresis) ---
    enum class Accion { Parar, Avanzar, Retroceder, Izquierda, Derecha };

    Accion        m_lastAction      = Accion::Parar;
    int           m_sameActionFrames = 0;      // frames consecutivos con la MISMA acción ganadora
    int           m_confirmFrames    = 3;      // N frames para confirmar antes de enviar
    int           m_minIntervalMs    = 200;    // rate-limit entre envíos de comandos
    QElapsedTimer m_actionTimer;                // cronómetro desde el último envío

    // Histéresis para colores (sube / baja)
    double m_colorUpThresh   = 0.18;  // requiere 18% para “entrar”
    double m_colorDownThresh = 0.12;  // baja a 12% para “salir”

    // Latch de colores
    bool m_color1Latched = false;
    bool m_color2Latched = false;



};
