#pragma once
#include <QObject>
#include <QImage>
#include <QPoint>
#include <QMutex>
#include <QVector>
#include <QRect>

#include <opencv2/core.hpp>

// Clase encargada de calibrar y detectar dos colores en espacio HSV.
// - Recibe frames (QImage RGBA) con processFrame(...)
// - Permite tomar un pixel HSV desde un click con handleClickOnHSV(...)
// - Mantiene dos rangos (color #1 y color #2)
// - Emite señales con la máscara y cobertura para cada color

class DetectorColores : public QObject
{
    Q_OBJECT
public:
    explicit DetectorColores(QObject* parent = nullptr);
    bool getRangoColor(int idx, int& hMin,int& sMin,int& vMin,
                       int& hMax,int& sMax,int& vMax) const;

    // Configuración básica
    void setCoverageThreshold(double frac);             // default 0.30
    void setActiveColorIndex(int idx);                  // 1 o 2
    void setToleranciasHSV(int dH, int dS, int dV);     // tolerancias para generar rango desde un pixel
    void setRangoColor(int idx,
                       int hMin, int sMin, int vMin,
                       int hMax, int sMax, int vMax);   // fijar rangos manualmente (opcional)
    void setCalibracionActiva(bool on);                 // modo calibrar ON/OFF

    // Flujo principal
    void processFrame(const QImage& rgbaFrame);         // corre inRange en ambos colores
    void handleClickOnHSV(const QPoint& pos,
                          const QImage& hsvImage);      // lee HSV del pixel clicado y actualiza el rango del color activo

    // Acceso (opcional)
    bool tieneColorCalibrado(int idx) const;

signals:
    // UI/helper
    void hsvLeido(int h, int s, int v);                 // para actualizar lcdNumber, lcdNumber_2, lcdNumber_3
    void rangoActualizado(int idx,
                          int hMin, int sMin, int vMin,
                          int hMax, int sMax, int vMax); // tras calibrar/guardar rango
    void estado(QString msg);

    // Resultados por frame
    void mascaraLista(int idx, QImage mask, double coverage);  // máscara binaria (8UC1->Grayscale8), fracción [0..1]
    void colorPredominante(int idx, double coverage);          // emitido si coverage >= umbral

private:
    // Helpers internos
    static cv::Mat qimageToMatRGBA(const QImage& img);  // sin copia si es posible
    static QImage  matGrayToQImage(const cv::Mat& m);   // copia segura

    void computeMasksFromRGBA(const QImage& rgbaFrame);

private:
    mutable QMutex m_mtx;

    // Rangos HSV para color 1 y 2
    cv::Scalar m_low1  {0,   0,   0};
    cv::Scalar m_high1 {179, 255, 255};
    cv::Scalar m_low2  {0,   0,   0};
    cv::Scalar m_high2 {179, 255, 255};
    bool m_has1 = false;
    bool m_has2 = false;

    // Control/calibración
    int  m_activeIdx = 1;    // 1 o 2
    int  m_dH = 10, m_dS = 40, m_dV = 40; // tolerancias por defecto
    bool m_calibrando = false;

    // Detección
    double m_coverageThresh = 0.30; // 30%
};
