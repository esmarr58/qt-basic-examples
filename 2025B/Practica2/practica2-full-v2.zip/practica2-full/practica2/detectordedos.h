#pragma once
#include <QObject>
#include <QImage>
#include <QPoint>
#include <QRect>
#include <QVector>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>

class DetectorDedos : public QObject {
    Q_OBJECT
public:
    explicit DetectorDedos(QObject *parent = nullptr);

    // Configurables (opcional)
    void setMinAreaContour(double px) { m_minAreaContour = px; }
    void setDepthThreshold(double d)  { m_defectDepthThresh = d; }
    void setAngleMaxDeg(double deg)   { m_angleMaxDeg = deg; }

public slots:
    void procesar(const QImage &img);  // recibe imagen RGBA/RGB/Gris

signals:
    // dedos: número 0..5; tips: puntos (coordenadas en la imagen); bbox: caja del contorno principal
    void resultado(int dedos, QVector<QPoint> tips, QRect bbox);

private:
    static cv::Mat qimageToBGR(const QImage &img);
    static double  angleBetween(const cv::Point& a, const cv::Point& b, const cv::Point& c);

private:
    double m_minAreaContour     = 5000.0; // área mínima para considerar contorno como mano
    double m_defectDepthThresh  = 15.0;   // profundidad mínima del defecto (en px) para dedo
    double m_angleMaxDeg        = 80.0;   // ángulo máximo (en grados) en la punta del dedo
};
