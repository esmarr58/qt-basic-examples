#include "trabajador_timer.h"
#include <QDebug>
#include <QTransform>
#include <opencv2/imgproc.hpp>

void FrameWorker::process(const QVideoFrame &frame) {
    if (!frame.isValid()) return;

    QImage img = frame.toImage();
    if (img.isNull()) return;

#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
    const int angle = int(frame.rotation());
    if (angle) {
        QTransform t; t.rotate(angle);
        img = img.transformed(t);
    }
#endif

    // Entregar crudo y estable
    emit ready(img.convertToFormat(QImage::Format_RGBA8888).copy());
}
