#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "trabajador_timer.h"
#include "websocketcliente.h"
#include "detector_sonrisas.h"
#include <QCoreApplication>
#include <QPermission>
#include <QResizeEvent>
#include <QPixmap>
#include <QDebug>
#include <cmath>
#include <QStatusBar>
#include <QLabel>
#include <QTimer>
#include <vector>
#include "detectorcolores.h"   // <-- incluye el .h aquí (no en mainwindow.h)
#include <QMetaObject>
#include <QUrl>
#include <QMouseEvent>
#include <QSettings>
#include <QCloseEvent>


// ---------- Selección de formato 16:9 (prioriza 1920x1080, luego 1280x720) ----------
static double scoreSize16x9(const QSize &r) {
    const int W = r.width(), H = r.height();
    const bool is16x9 = (std::abs(W*9 - H*16) <= 2);
    double base = is16x9 ? 0.0 : 1000.0;  // penaliza fuerte si no es 16:9
    // distancia a 1920x1080 (más cerca, mejor)
    double d = std::hypot(double(W - 1920), double(H - 1080));
    return base + d;
}

QCameraFormat MainWindow::pickFormat16x9(const QCameraDevice &dev) {
    QCameraFormat best;
    double bestScore = 1e18;
    for (const auto &fmt : dev.videoFormats()) {
        if (fmt.maxFrameRate() < 30.0) continue;        // pide >= 30fps
        double s = scoreSize16x9(fmt.resolution());
        if (s < bestScore) { bestScore = s; best = fmt; }
    }
    return best; // puede quedar nulo si no encuentra >=30fps 16:9
}

// ---------- Permisos ----------
void MainWindow::pedirPermisosCamara() {
    QCameraPermission permiso;
    switch (qApp->checkPermission(permiso)) {
    case Qt::PermissionStatus::Granted:
        qDebug() << "[Permisos] Cámara ya concedida";
        iniciarCamaraSiHayPermiso();
        return;
    case Qt::PermissionStatus::Denied:
        qDebug() << "[Permisos] Cámara denegada por el sistema";
        return;
    case Qt::PermissionStatus::Undetermined:
        qDebug() << "[Permisos] Solicitando permiso de cámara…";
        qApp->requestPermission(permiso, this, [this](const QPermission &p){
            if (p.status() == Qt::PermissionStatus::Granted) {
                qDebug() << "[Permisos] Cámara concedida (callback)";
                QMetaObject::invokeMethod(this, [this]{ iniciarCamaraSiHayPermiso(); },
                                          Qt::QueuedConnection);
            } else {
                qDebug() << "[Permisos] Cámara no concedida en callback";
            }
        });
        return;
    }
}

// ---------- Resize (escala manteniendo aspecto) ----------
void MainWindow::resizeEvent(QResizeEvent *e) {
    QMainWindow::resizeEvent(e);

    if (m_lastImg.isNull()) return;

    const int targetW = ui->label->width();
    const int targetH = qRound(double(targetW) * m_lastImg.height() / m_lastImg.width());
    ui->label->setFixedSize(targetW, targetH);

    ui->label->setPixmap(
        QPixmap::fromImage(m_lastImg).scaled(ui->label->size(),
                                             Qt::KeepAspectRatio,
                                             Qt::SmoothTransformation)
        );
}

// ---------- Arranque de cámara (GUI thread) ----------
void MainWindow::iniciarCamaraSiHayPermiso() {
    QCameraPermission permiso;
    if (qApp->checkPermission(permiso) != Qt::PermissionStatus::Granted) {
        qDebug() << "[Cámara] No se puede iniciar: permiso NO concedido";
        return;
    }

    const auto cams = QMediaDevices::videoInputs();
    if (cams.isEmpty()) {
        qDebug() << "[Cámara] No hay cámaras disponibles";
        return;
    }

    // Log de resoluciones soportadas (útil para depurar)
    for (const auto &cam : cams) {
        qDebug() << "[Cámara]" << cam.description();
        for (const auto &fmt : cam.videoFormats()) {
            const QSize res = fmt.resolution();
            qDebug() << "   Resolución:" << res.width() << "x" << res.height()
                     << "fps:" << fmt.minFrameRate() << "-" << fmt.maxFrameRate();
        }
    }

    // Toma la primera cámara (ajusta según descripción si requieres otra)
    const QCameraDevice dev = cams.front();
    m_camera = std::make_unique<QCamera>(dev);

    // *** Conectar errores AQUÍ (ya existe m_camera) ***
    connect(m_camera.get(), &QCamera::errorOccurred, this,
            [this](QCamera::Error e, const QString &s){
                qDebug() << "[Cámara][error]" << e << s;

                const QString msg = s.isEmpty()
                                        ? tr("Error de cámara")
                                        : s;

                // Heurística: ocupado por otra app
                const QString lower = msg.toLower();
                const bool ocupado =
                    lower.contains("busy") ||
                    lower.contains("in use") ||
                    lower.contains("ocup") ||           // “ocupado”
                    lower.contains("device or resource busy");

                if (ocupado) {
                    setStatusError(tr("Cámara ocupada por otra aplicación"));
                    QMessageBox::critical(
                        this,
                        tr("Error de cámara"),
                        ocupado
                            ? tr("La cámara está ocupada por otra aplicación.\n\nCierra el otro programa y vuelve a intentarlo.")
                            : msg
                        );

                } else {
                    setStatusError(msg);
                }
            });

    // Estado activo/inactivo (no marcar activa si hay error)
    connect(m_camera.get(), &QCamera::activeChanged, this, [this](bool activa){
        if (activa && m_camera->error() == QCamera::NoError) {
            setStatusOk(tr("Cámara activa"));
        } else if (!activa) {
            setStatusError(tr("Cámara no activa"));
        }
    });

    // Elige 16:9 “cercano” a 1920x1080/1280x720 (>=30fps)
    QCameraFormat chosen = pickFormat16x9(dev);

    // (Fallback opcional) si no hay 16:9 a 30fps, podrías elegir 640x480@30fps
    if (chosen.isNull()) {
        for (const auto &fmt : dev.videoFormats()) {
            const auto r = fmt.resolution();
            if (r.width() == 640 && r.height() == 480 && fmt.maxFrameRate() >= 30.0) {
                chosen = fmt;
                break;
            }
        }
    }

    if (!chosen.isNull()) {
        m_camera->setCameraFormat(chosen);
        qDebug() << "[Cam] usando" << chosen.resolution() << "@"
                 << chosen.maxFrameRate() << "fps";
    } else {
        qDebug() << "[Cam] no se encontró formato deseado; usando default del backend";
    }

    // Crear sink (GUI thread)
    if (!m_sink) m_sink = std::make_unique<QVideoSink>();

    // Bandera local para detectar primer frame
    static bool s_gotFirstFrame = false;
    s_gotFirstFrame = false;

    // Conectar UNA vez: GUI -> worker (dropear si ocupado)
    if (!m_sinkConnected) {
        connect(m_sink.get(), &QVideoSink::videoFrameChanged, this,
                [this](const QVideoFrame &f) {
                    if (!f.isValid()) return;
                    if (!m_lastImg.isNull() == false && !statusBar()->isHidden()) {
                        // nada
                    }
                    if (!s_gotFirstFrame) {
                        setStatusOk(tr("Recibiendo video"));
                        s_gotFirstFrame = true;
                    }

                    if (m_busy.exchange(true)) return;

                    QVideoFrame fcopy(f); // compatible Qt 6.2–6.9
                    QMetaObject::invokeMethod(m_worker, [this, fcopy]{
                        m_worker->process(fcopy);
                    }, Qt::QueuedConnection);
                },
                Qt::QueuedConnection);

        m_sinkConnected = true;
    }

    // Orden correcto: primero sink, luego cámara, luego start()
    m_session.setVideoSink(m_sink.get());
    m_session.setCamera(m_camera.get());

    qDebug() << "[Cámara] start()";
    setStatusOk(tr("Iniciando cámara…"));
    m_camera->start();

    // Watchdog: si no hay frames tras 1200 ms y no hay error explícito, avisa
    QTimer::singleShot(1200, this, [this]{
        if (m_lastImg.isNull() && m_camera && m_camera->error() == QCamera::NoError) {
            setStatusError(tr("Sin señal de video"));
        }
    });
}


inline void limpiarOverlayColor(int idx,
                                QImage& m1, QImage& m2,
                                bool& p1, bool& p2,
                                double& c1, double& c2)
{
    if (idx == 1) {
        m1 = QImage();
        p1 = false;
        c1 = 0.0;
    } else if (idx == 2) {
        m2 = QImage();
        p2 = false;
        c2 = 0.0;
    } else if (idx == 0) {
        // 0 = ambos
        m1 = QImage();
        p1 = false;
        c1 = 0.0;
        m2 = QImage();
        p2 = false;
        c2 = 0.0;
    }
}

void MainWindow::onImageReady(const QImage &img)
{
    m_lastImg = img;
    if (m_lastImg.isNull()) { m_busy = false; return; }

    // === Base RGBA (sin copia) ===
    QImage qrgba = m_lastImg.convertToFormat(QImage::Format_RGBA8888);
    cv::Mat rgba(qrgba.height(), qrgba.width(), CV_8UC4,
                 const_cast<uchar*>(qrgba.bits()), qrgba.bytesPerLine());

    // === Calculamos SIEMPRE RGB/HSV para tener m_lastHSV disponible ===
    cv::Mat rgb;  cv::cvtColor(rgba, rgb, cv::COLOR_RGBA2RGB);
    cv::Mat hsv;  cv::cvtColor(rgb,  hsv, cv::COLOR_RGB2HSV);

    // Guardar HSV como QImage::Format_RGB888 (H,S,V en 3 canales)
    {
        QImage hsvQ((uchar*)hsv.data, hsv.cols, hsv.rows,
                    (int)hsv.step, QImage::Format_RGB888);
        m_lastHSV = hsvQ.copy();  // copia para buffer propio
    }

    // === Visualización (gris / HSV "H con S=V=255") ===
    QImage toShow;
    if (ui->checkBox->isChecked()) {
        cv::Mat gray;
        cv::cvtColor(rgba, gray, cv::COLOR_RGBA2GRAY);
        toShow = QImage(gray.data, gray.cols, gray.rows,
                        static_cast<int>(gray.step), QImage::Format_Grayscale8).copy();
    } else {
        std::vector<cv::Mat> ch; cv::split(hsv, ch);
        cv::Mat fullS(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));
        cv::Mat fullV(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));
        cv::Mat hsvVis; cv::merge(std::vector<cv::Mat>{ ch[0], fullS, fullV }, hsvVis);

        cv::Mat rgbVis; cv::cvtColor(hsvVis, rgbVis, cv::COLOR_HSV2RGB);
        toShow = QImage(rgbVis.data, rgbVis.cols, rgbVis.rows,
                        static_cast<int>(rgbVis.step), QImage::Format_RGB888).copy();
    }

    // === Filtro por área mínima (9%) SOLO para CARAS ===
    const double imgAreaRef = double(toShow.width()) * double(toShow.height());
    auto filterFacesByArea = [&](const QVector<QRect>& in)->QVector<QRect> {
        QVector<QRect> out; out.reserve(in.size());
        for (const QRect& r : in) {
            const double a  = double(r.width()) * double(r.height());
            const double fr = (imgAreaRef > 0.0) ? (a / imgAreaRef) : 0.0; // fracción 0..1
            if (fr >= 0.09) out.push_back(r);
        }
        return out;
    };
    const QVector<QRect> carasFiltradas    = filterFacesByArea(m_rectsCaras);
    const QVector<QRect> sonrisasFiltradas = m_rectsSonrisas; // <- sin filtro de área
    const bool hayCaraFiltrada    = !carasFiltradas.isEmpty();
    const bool haySonrisa         = !m_rectsSonrisas.isEmpty(); // estado usa existencia real

    // === Imagen anotada ARGB ===
    QImage annotated = toShow.convertToFormat(QImage::Format_ARGB32);

    // === Rectángulos de detección (caras / sonrisas) ===
    {
        QPainter p(&annotated);
        p.setRenderHint(QPainter::Antialiasing, true);

        QPen penCara(Qt::yellow); penCara.setWidth(2);
        p.setPen(penCara);
        for (const QRect &r : carasFiltradas) p.drawRect(r);

        QPen penSonrisa(Qt::green); penSonrisa.setWidth(2); penSonrisa.setStyle(Qt::DashLine);
        p.setPen(penSonrisa);
        for (const QRect &r : sonrisasFiltradas) p.drawRect(r);
    }

    // === Overlay de color: teñir máscaras ===
    auto blendMask = [](QImage& dst, const QImage& mask, const QColor& color, int alpha){
        if (mask.isNull() || dst.size() != mask.size()) return;
        QImage m = mask.convertToFormat(QImage::Format_Grayscale8);
        QPainter p(&dst);
        p.setRenderHint(QPainter::Antialiasing, false);
        p.setCompositionMode(QPainter::CompositionMode_SourceOver);
        const int w = m.width(), h = m.height();
        QColor c = color; c.setAlpha(alpha);
        p.setPen(Qt::NoPen);
        for (int y = 0; y < h; ++y) {
            const uchar* row = m.constScanLine(y);
            int x = 0;
            while (x < w) {
                while (x < w && row[x] == 0) ++x;     // salta negros
                const int x0 = x;
                while (x < w && row[x] != 0) ++x;     // corre blancos
                if (x0 < x) { p.setBrush(c); p.drawRect(QRect(x0, y, x - x0, 1)); }
            }
        }
    };
    if (!m_maskColor1.isNull()) blendMask(annotated, m_maskColor1, QColor(255,255,0), 90);
    if (!m_maskColor2.isNull()) blendMask(annotated, m_maskColor2, QColor(0,255,0), 90);

    // === Mensajes apilados (estado, colores, áreas) ===
    {
        struct Item { QString text; QColor color; };
        QVector<Item> msgs;

        // Estado cara/sonrisa (cara ya filtrada; sonrisa solo existencia)
        const QString estado = hayCaraFiltrada
                                   ? (haySonrisa ? tr("Cara 🙂 (sonrisa)") : tr("Cara"))
                                   : tr("Buscando…");
        msgs.push_back({ estado, Qt::white });

        // Colores por cobertura (usa tu umbral configurable)
        if (m_cov1 >= m_colorThresh) {
            msgs.push_back({ tr("color 1 encontrado (%1%)")
                             .arg(QString::number(m_cov1*100.0, 'f', 1)),
                             Qt::yellow });
        }
        if (m_cov2 >= m_colorThresh) {
            msgs.push_back({ tr("color 2 encontrado (%1%)")
                             .arg(QString::number(m_cov2*100.0, 'f', 1)),
                             Qt::green });
        }

        // Áreas relativas (cara: filtradas; sonrisa: sin filtrar)
        const double imgArea = double(annotated.width()) * double(annotated.height());
        auto maxFrac = [&](const QVector<QRect>& rects)->double {
            double mx = 0.0;
            for (const QRect& r : rects) {
                const double a = double(r.width()) * double(r.height());
                const double f = (imgArea > 0.0) ? (a / imgArea) : 0.0; // 0..1
                if (f > mx) mx = f;
            }
            return mx;
        };
        const double caraFrac    = maxFrac(carasFiltradas);
        const double sonrisaFrac = maxFrac(m_rectsSonrisas);

        if (caraFrac >= 0.09) {
            msgs.push_back({ tr("Cara detectada (%1%)")
                             .arg(QString::number(caraFrac * 100.0, 'f', 1)),
                             Qt::yellow });
        }
        if (haySonrisa) {
            msgs.push_back({ tr("Sonrisa detectada (%1%)")
                             .arg(QString::number(sonrisaFrac * 100.0, 'f', 1)),
                             Qt::green });
        }

        if (!msgs.isEmpty()) {
            QPainter p(&annotated);
            p.setRenderHint(QPainter::Antialiasing, true);

            QFont f = p.font();
            f.setBold(true);
            f.setPointSize(std::max(12, annotated.width()/50));
            p.setFont(f);

            const QFontMetrics fm(f);
            const int lineH = fm.height();
            const int padX  = 10;
            const int padY  = 8;
            const int gap   = 4;

            // calcular ancho máximo
            int maxW = 0;
            for (const auto& it : msgs) maxW = std::max(maxW, fm.horizontalAdvance(it.text));
            const int blockW = maxW + padX*2;
            const int blockH = int(msgs.size()) * lineH + (int(msgs.size())-1) * gap + padY*2;

            // esquina superior izquierda (márgenes 8 px)
            const int bgX = 8;
            const int bgY = 8;
            QRect bgRect(bgX, bgY, blockW, blockH);

            // fondo semitransparente
            p.setPen(Qt::NoPen);
            p.setBrush(QColor(0,0,0,140));
            p.drawRoundedRect(bgRect, 8, 8);

            // dibujar líneas
            int y = bgY + padY + fm.ascent();
            const int x = bgX + padX;

            for (const auto& it : msgs) {
                // sombra
                p.setPen(QColor(0,0,0,180));
                p.drawText(QPoint(x+1, y+1), it.text);
                // texto
                p.setPen(it.color);
                p.drawText(QPoint(x, y), it.text);
                y += (lineH + gap);
            }
        }
    }

    // ===========================
    //     DECISIÓN DE GANADOR
    // ===========================
    enum class Winner { Parar, Sonrisa, Cara, Color1, Color2 };

    Winner winner = Winner::Parar;

    // 1) Sonrisa domina si hay cara ≥ 9% y hay sonrisa
    if (hayCaraFiltrada && haySonrisa) {
        winner = Winner::Sonrisa;
    }
    // 2) Si no, Cara si ≥ 9%
    else if (hayCaraFiltrada) {
        winner = Winner::Cara;
    }
    // 3) Si no, colores sobre umbral (elige el de mayor cobertura si ambos)
    else {
        const bool c1ok = (m_cov1 >= m_colorThresh);
        const bool c2ok = (m_cov2 >= m_colorThresh);
        if (c1ok || c2ok) {
            if (c1ok && c2ok) {
                winner = (m_cov1 >= m_cov2) ? Winner::Color1 : Winner::Color2;
            } else if (c1ok) {
                winner = Winner::Color1;
            } else {
                winner = Winner::Color2;
            }
        } else {
            winner = Winner::Parar;
        }
    }

    // ===========================
    //     ENVÍO JSON RATE-LIMIT
    // ===========================
    // Envía SOLO 1 comando cada 1000 ms, según el ganador.
    // Mapea: Sonrisa->retroceder(100), Cara->avanzar(100), Color1->derecha(50), Color2->izquierda(50), Parar->parar(0)
    static QElapsedTimer s_cmdTimer;
    static bool s_inited = false;
    static QString s_lastCmd = QStringLiteral("parar");
    static int     s_lastMs  = 0;
    static QElapsedTimer s_lastCmdAge; // para mostrar "hace X ms"

    if (!s_inited) { s_cmdTimer.start(); s_lastCmdAge.start(); s_inited = true; }

    auto sendMover = [this](const QString& accion, int ms){
        QMetaObject::invokeMethod(m_ws, [this, accion, ms](){
            QJsonObject obj{
                {"tipo",   "mover"},
                {"accion", accion},            // "avanzar" | "retroceder" | "izquierda" | "derecha" | "parar"
                {"ms",     ms}
            };
            m_ws->enviarJson(obj);
        }, Qt::QueuedConnection);
    };

    if (s_cmdTimer.elapsed() >= 1000) {
        switch (winner) {
        case Winner::Sonrisa: sendMover(QStringLiteral("retroceder"), 100); s_lastCmd = "retroceder"; s_lastMs = 100; break;
        case Winner::Cara:    sendMover(QStringLiteral("avanzar"),    100); s_lastCmd = "avanzar";    s_lastMs = 100; break;
        case Winner::Color1:  sendMover(QStringLiteral("derecha"),     50); s_lastCmd = "derecha";     s_lastMs = 50;  break;
        case Winner::Color2:  sendMover(QStringLiteral("izquierda"),   50); s_lastCmd = "izquierda";   s_lastMs = 50;  break;
        case Winner::Parar:   sendMover(QStringLiteral("parar"),        0); s_lastCmd = "parar";       s_lastMs = 0;   break;
        }
        s_cmdTimer.restart();
        s_lastCmdAge.restart();
    }

    // ===========================
    //  OVERLAY INFERIOR CENTRADO
    //  (Último comando enviado)
    // ===========================
    {
        const int ageMs = s_lastCmdAge.isValid() ? int(s_lastCmdAge.elapsed()) : -1;
        const QString info = (ageMs >= 0)
                                 ? tr("Ultimo cmd: %1 (%2 ms) • hace %3 ms")
                                       .arg(s_lastCmd)
                                       .arg(s_lastMs)
                                       .arg(ageMs)
                                 : tr("Ultimo cmd: %1 (%2 ms)").arg(s_lastCmd).arg(s_lastMs);

        QPainter p(&annotated);
        p.setRenderHint(QPainter::Antialiasing, true);

        QFont f = p.font();
        f.setBold(true);
        f.setPointSize(std::max(12, annotated.width()/55));
        p.setFont(f);

        const QFontMetrics fm(f);
        const int padX = 12;
        const int padY = 8;
        const int textW = fm.horizontalAdvance(info);
        const int textH = fm.height();
        const int blockW = textW + padX*2;
        const int blockH = textH + padY*2;

        const int x = (annotated.width() - blockW) / 2;
        const int y = annotated.height() - blockH - 10;  // 10 px del borde inferior

        // Fondo semitransparente
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(0,0,0,150));
        p.drawRoundedRect(QRect(x, y, blockW, blockH), 10, 10);

        // Texto con pequeña sombra
        const int tx = x + padX;
        const int ty = y + padY + fm.ascent();
        p.setPen(QColor(0,0,0,200));
        p.drawText(QPoint(tx+1, ty+1), info);
        p.setPen(Qt::white);
        p.drawText(QPoint(tx, ty), info);
    }

    // === Pintado (sin setFixedSize) ===
    const int w = ui->label->width();
    const int h = ui->label->height();
    const int targetW = (w > 0 ? w : annotated.width());
    const int targetH = (h > 0 ? h : annotated.height());

    ui->label->setPixmap(
        QPixmap::fromImage(annotated).scaled(
            QSize(targetW, targetH),
            Qt::KeepAspectRatio,
            Qt::SmoothTransformation
            )
        );

    m_busy = false;
}


// ---------- Ctor / Dtor ----------
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    ui->setupUi(this);



    // Permitir capturar clics del mouse sobre el QLabel de video
    ui->label->setMouseTracking(true);
    ui->label->installEventFilter(this);


    m_statusLbl = new QLabel(this);
    m_statusLbl->setText(QString());                   // vacío
    m_statusLbl->setStyleSheet("color: #2e7d32;");     // verde por defecto (OK)
    statusBar()->addPermanentWidget(m_statusLbl, 1);

    // Worker en hilo propio (solo CPU, nada de GUI/GL aquí)
    m_worker = new FrameWorker();
    m_worker->moveToThread(&m_workerThread);
    connect(&m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    m_workerThread.start();

    // Worker -> GUI: pintar imagen
    connect(m_worker, &FrameWorker::ready, this, &MainWindow::onImageReady,
            Qt::QueuedConnection);

    // Pedir permisos y arrancar cámara si procede
    pedirPermisosCamara();

    // (OJO) no conectamos errorOccurred aquí; se conecta tras crear m_camera

    //  CONFIGURACIÓN SONRISAS (usa DetectorSonrisas; ya no usamos DetectorDedos aquí)
    // ===============================
    m_detector = new DetectorSonrisas();
    m_detector->moveToThread(&m_hiloSonrisas);
    connect(&m_hiloSonrisas, &QThread::finished, m_detector, &QObject::deleteLater);
    m_hiloSonrisas.start();

    // Worker -> DetectorSonrisas
    connect(m_worker, &FrameWorker::ready,
            m_detector, &DetectorSonrisas::procesar,
            Qt::QueuedConnection);

    // DetectorSonrisas -> MainWindow (estado para overlay)
    connect(m_detector, &DetectorSonrisas::resultado,
            this, [this](bool hayCara, bool haySonrisa,
                   const QVector<QRect>& rectsCaras,
                   const QVector<QRect>& rectsSonrisas){
                m_hayCara       = hayCara;
                m_haySonrisa    = haySonrisa;
                m_rectsCaras    = rectsCaras;
                m_rectsSonrisas = rectsSonrisas;
            },
            Qt::QueuedConnection);

    m_ws = new WebSocketCliente(nullptr);
    m_ws->moveToThread(&m_wsThread);
    connect(&m_wsThread, &QThread::finished, m_ws, &QObject::deleteLater);

    // 2) Conexiones válidas con la clase actual
    connect(m_ws, &WebSocketCliente::conectado, this, [this](){
        qDebug() << "[WS] conectado";
    });
    connect(m_ws, &WebSocketCliente::desconectado, this, [this](){
        qDebug() << "[WS] desconectado";
    });
    connect(m_ws, &WebSocketCliente::estadoCambiado, this, [this](QAbstractSocket::SocketState s){
        qDebug() << "[WS] estado:" << s;
    });
    connect(m_ws, &WebSocketCliente::errorTexto, this, [this](const QString& e){
        qWarning() << "[WS] error:" << e;
    });
    connect(m_ws, &WebSocketCliente::saludoRecibido, this, [this](const QJsonObject& saludo){
        qDebug() << "[WS] saludo:" << saludo;
    });
    connect(m_ws, &WebSocketCliente::latidoOk, this, [this](uint32_t tms){
        qDebug() << "[WS] latido_ok en" << tms << "ms";
    });
    connect(m_ws, &WebSocketCliente::dhtLectura, this, [this](bool ok, double T, double H){
        qDebug() << "[WS] DHT:" << ok << "T=" << T << "H=" << H;
    });
    connect(m_ws, &WebSocketCliente::ledAck, this, [this](bool estado){
        qDebug() << "[WS] led_ack:" << estado;
    });
    connect(m_ws, &WebSocketCliente::rgbAck, this, [this](int r,int g,int b){
        qDebug() << "[WS] rgb_ack:" << r << g << b;
    });
    connect(m_ws, &WebSocketCliente::moverAck, this, [this](const QString& accion, uint32_t ms){
        qDebug() << "[WS] mover_ack:" << accion << ms;
    });
    connect(m_ws, &WebSocketCliente::moverErr, this, [this](const QString& accion, uint32_t ms){
        qWarning() << "[WS] mover_err:" << accion << ms;
    });
    connect(m_ws, &WebSocketCliente::telemetria, this, [this](const QJsonObject& payload){
        qDebug() << "[WS] telemetria:" << payload;
        // aquí actualizas UI si quieres
    });

    // 3) Arrancar hilo y conectar
    m_wsThread.start();

    const QUrl url(QStringLiteral("ws://%1:%2/").arg(ipESP32, "81"));
    QMetaObject::invokeMethod(m_ws, [this, url](){
        m_ws->setUrl(url);
        m_ws->setHeartbeatInterval(2000); // opcional
        m_ws->conectar();
    }, Qt::QueuedConnection);

    m_color = new DetectorColores(nullptr);
    m_color->moveToThread(&m_colorThread);
    connect(&m_colorThread, &QThread::finished, m_color, &QObject::deleteLater);

    // Señales del detector -> UI
    connect(m_color, &DetectorColores::estado, this, [this](const QString& s){
        statusBar()->showMessage(s, 2000);
    });
    connect(m_color, &DetectorColores::hsvLeido, this, [this](int h, int s, int v){
        if (ui->lcdNumber)   ui->lcdNumber  ->display(h);
        if (ui->lcdNumber_2) ui->lcdNumber_2->display(s);
        if (ui->lcdNumber_3) ui->lcdNumber_3->display(v);
    });
    connect(m_color, &DetectorColores::rangoActualizado, this,
            [this](int idx, int hMin,int sMin,int vMin,int hMax,int sMax,int vMax){
                qDebug() << "[Color]" << idx << "rango:"
                         << hMin<<sMin<<vMin << "->" << hMax<<sMax<<vMax;

                // Guardar con QSettings
                QSettings st("Tecnocircuito", "CamaraHilos1");
                const QString p = (idx == 1) ? "color1/" : "color2/";
                st.setValue(p + "hMin", hMin);
                st.setValue(p + "sMin", sMin);
                st.setValue(p + "vMin", vMin);
                st.setValue(p + "hMax", hMax);
                st.setValue(p + "sMax", sMax);
                st.setValue(p + "vMax", vMax);
            });


    connect(m_color, &DetectorColores::mascaraLista, this,
            [this](int idx, const QImage& mask, double cov){
                if (idx == 1) { m_maskColor1 = mask; m_cov1 = cov; }
                else          { m_maskColor2 = mask; m_cov2 = cov; }

                // Mostrar porcentaje de cobertura con dos decimales
                qDebug().noquote() << QString("[Color %1] cobertura: %2%")
                                          .arg(idx)
                                          .arg(QString::number(cov * 100.0, 'f', 2));

                // flags se actualizan con colorPredominante
            });


    connect(m_color, &DetectorColores::colorPredominante, this,
            [this](int idx, double cov){
                if (idx == 1) m_pred1 = true, m_cov1 = cov;
                if (idx == 2) m_pred2 = true, m_cov2 = cov;
                // (el reseteo a false lo haremos en el siguiente paso al inicio de cada frame)
            });

    // Opcional: umbral 30% y tolerancias
    QMetaObject::invokeMethod(m_color, [this](){
        m_color->setCoverageThreshold(m_colorThresh);
        m_color->setToleranciasHSV(10, 40, 40);
    }, Qt::QueuedConnection);

    // Radio buttons -> color activo (1 o 2)
    connect(ui->radioButton, &QRadioButton::toggled, this, [this](bool on){
        if (!on || !m_color) return;
        m_colorActivo = 1;
        // NUEVO: limpiar overlay del color 1 al activarlo (especialmente si vas a recalibrar)
        limpiarOverlayColor(1, m_maskColor1, m_maskColor2, m_pred1, m_pred2, m_cov1, m_cov2);

        QMetaObject::invokeMethod(m_color, [this](){
            m_color->setActiveColorIndex(1);
        }, Qt::QueuedConnection);
    });

    connect(ui->radioButton_2, &QRadioButton::toggled, this, [this](bool on){
        if (!on || !m_color) return;
        m_colorActivo = 2;
        // NUEVO: limpiar overlay del color 2 al activarlo
        limpiarOverlayColor(2, m_maskColor1, m_maskColor2, m_pred1, m_pred2, m_cov1, m_cov2);

        QMetaObject::invokeMethod(m_color, [this](){
            m_color->setActiveColorIndex(2);
        }, Qt::QueuedConnection);
    });

    // Estado inicial (color 1 activo)
    if (ui->radioButton) ui->radioButton->setChecked(true);

    // Botón "pushButton": lo usaremos como Calibrar/Guardar (toggle)
    ui->pushButton->setCheckable(true);
    ui->pushButton->setText(tr("Calibrar"));
    connect(ui->pushButton, &QPushButton::toggled, this, [this](bool on){
        m_calibrandoColor = on;
        ui->pushButton->setText(on ? tr("Guardar") : tr("Calibrar"));
        if (!m_color) return;

        // Activar/desactivar modo calibración en el detector
        QMetaObject::invokeMethod(m_color, [this, on](){
            m_color->setCalibracionActiva(on);
        }, Qt::QueuedConnection);

        // --- NUEVO: limpiar overlays al iniciar calibración del color activo ---
        if (on) {
            limpiarOverlayColor(m_colorActivo,
                                m_maskColor1, m_maskColor2,
                                m_pred1, m_pred2,
                                m_cov1,  m_cov2);
        }
    });


    // Conectar frames del worker -> detector de colores (corre en su hilo)
    connect(m_worker, &FrameWorker::ready, m_color, &DetectorColores::processFrame,
            Qt::QueuedConnection);

    // Arrancar hilo del detector
    m_colorThread.start();
    // === Restaurar rangos guardados ===
    QSettings st("Tecnocircuito", "CamaraHilos1"); // vendor/app (ajusta si quieres)
    auto cargarRango = [&](int idx){
        const QString p = (idx == 1) ? "color1/" : "color2/";
        const int hMin = st.value(p + "hMin", -1).toInt();
        const int sMin = st.value(p + "sMin", -1).toInt();
        const int vMin = st.value(p + "vMin", -1).toInt();
        const int hMax = st.value(p + "hMax", -1).toInt();
        const int sMax = st.value(p + "sMax", -1).toInt();
        const int vMax = st.value(p + "vMax", -1).toInt();
        if (hMin >= 0 && sMin >= 0 && vMin >= 0 && hMax >= 0 && sMax >= 0 && vMax >= 0) {
            QMetaObject::invokeMethod(m_color, [=](){
                m_color->setRangoColor(idx, hMin,sMin,vMin, hMax,sMax,vMax);
            }, Qt::QueuedConnection);
        }
    };
    cargarRango(1);
    cargarRango(2);

    m_actionTimer.start();


}

MainWindow::~MainWindow() {
    m_colorThread.quit();
    m_colorThread.wait();

    m_hiloSonrisas.quit();
    m_hiloSonrisas.wait();

    m_workerThread.quit();
    m_workerThread.wait();

    if (m_ws) {
        QMetaObject::invokeMethod(m_ws, [this](){ m_ws->cerrar(); }, Qt::QueuedConnection);
    }
    m_wsThread.quit();
    m_wsThread.wait();

    delete ui;
}

void MainWindow::setStatusOk(const QString &msg) {
    m_statusLbl->setStyleSheet("color: #2e7d32; font-weight: 600;"); // verde
    m_statusLbl->setText(msg);
}

void MainWindow::setStatusError(const QString &msg) {
    m_statusLbl->setStyleSheet("color: #c62828; font-weight: 700;"); // rojo
    m_statusLbl->setText(msg);
}

void MainWindow::on_checkBox_clicked()
{
    if(ui->checkBox->isChecked()){
        ui->checkBox->setText("HSV");
    }
    else ui->checkBox->setText("Gris");
}


static QPoint mapPointToImage(const QPoint& pLabel, const QSize& imgSize, const QSize& labelSize)
{
    const double iw = imgSize.width(), ih = imgSize.height();
    const double lw = labelSize.width(), lh = labelSize.height();
    if (iw <= 0 || ih <= 0 || lw <= 0 || lh <= 0) return QPoint(-1,-1);

    const double s = std::min(lw/iw, lh/ih);
    const int drawW = int(iw * s);
    const int drawH = int(ih * s);
    const int offX  = int((lw - drawW) / 2.0);
    const int offY  = int((lh - drawH) / 2.0);

    const int xRel = pLabel.x() - offX;
    const int yRel = pLabel.y() - offY;
    if (xRel < 0 || yRel < 0 || xRel >= drawW || yRel >= drawH) return QPoint(-1,-1);

    const double inv = 1.0 / s;
    const int xi = int(std::round(xRel * inv));
    const int yi = int(std::round(yRel * inv));
    if (xi < 0 || yi < 0 || xi >= iw || yi >= ih) return QPoint(-1,-1);
    return QPoint(xi, yi);
}

bool MainWindow::eventFilter(QObject* obj, QEvent* event)
{
    if (obj == ui->label && event->type() == QEvent::MouseButtonPress) {
        auto* me = static_cast<QMouseEvent*>(event);

        if (m_calibrandoColor && !m_lastHSV.isNull() && m_color) {
            const QPoint pImg = mapPointToImage(me->pos(), m_lastHSV.size(), ui->label->size());
            if (pImg.x() >= 0 && pImg.y() >= 0) {
                // Enviar el pixel al hilo del detector
                QImage hsvCopy = m_lastHSV.copy(); // copia segura
                QMetaObject::invokeMethod(m_color, [this, pImg, hsvCopy]() {
                    m_color->handleClickOnHSV(pImg, hsvCopy);
                }, Qt::QueuedConnection);
            }
        }
        return true; // consumimos el evento
    }
    return QMainWindow::eventFilter(obj, event);
}

void MainWindow::closeEvent(QCloseEvent* e)
{
    if (m_color) {
        // Lee rangos actuales (si existen) y persiste
        for (int idx : {1,2}) {
            int hMin,sMin,vMin,hMax,sMax,vMax;
            if (m_color->getRangoColor(idx, hMin,sMin,vMin, hMax,sMax,vMax)) {
                QSettings st("Tecnocircuito", "CamaraHilos1");
                const QString p = (idx == 1) ? "color1/" : "color2/";
                st.setValue(p + "hMin", hMin);
                st.setValue(p + "sMin", sMin);
                st.setValue(p + "vMin", vMin);
                st.setValue(p + "hMax", hMax);
                st.setValue(p + "sMax", sMax);
                st.setValue(p + "vMax", vMax);
            }
        }
    }
    QMainWindow::closeEvent(e);
}
