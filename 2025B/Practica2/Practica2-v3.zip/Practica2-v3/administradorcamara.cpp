#include "administradorcamara.h"
#include <QCoreApplication>
#include <QMetaObject>
#include <QMessageBox>
#include <QDebug>
#include <cmath>

static double scoreSize16x9(const QSize &r) {
    const int W = r.width(), H = r.height();
    const bool is16x9 = (std::abs(W*9 - H*16) <= 2);
    double base = is16x9 ? 0.0 : 1000.0;
    double d = std::hypot(double(W - 1920), double(H - 1080));
    return base + d;
}

QCameraFormat CameraManager::pickFormat16x9(
    const QCameraDevice &dev) {
    QCameraFormat best;
    double bestScore = 1e18;
    for (const auto &fmt : dev.videoFormats()) {
        if (fmt.maxFrameRate() < 30.0) continue;
        double s = scoreSize16x9(fmt.resolution());
        if (s < bestScore) { bestScore = s; best = fmt; }
    }
    return best;
}

CameraManager::CameraManager(QObject* parent)
    : QObject(parent) {}
CameraManager::~CameraManager() {
    if (m_camera) m_camera->stop();
}
void CameraManager::start() {
    pedirPermisosCamara();
}

void CameraManager::pedirPermisosCamara() {
    QCameraPermission permiso;
    switch (qApp->checkPermission(permiso)) {
    case Qt::PermissionStatus::Granted:
        emit statusOk(tr("Cámara: permiso concedido"));
        iniciarCamaraSiHayPermiso();
        return;
    case Qt::PermissionStatus::Denied:
        emit statusError(tr("Cámara: permiso denegado"));
        return;
    case Qt::PermissionStatus::Undetermined:
        emit statusOk(tr("Cámara: solicitando permiso..."));
        qApp->requestPermission(permiso, this,
                                [this](const QPermission &p){
                                    if (p.status() == Qt::PermissionStatus::Granted) {
                                        QMetaObject::invokeMethod(this,
                                                                  [this]{ iniciarCamaraSiHayPermiso(); },
                                                                  Qt::QueuedConnection);
                                    } else {
                                        emit statusError(tr("Cámara: permiso no concedido"));
                                    }
                                });
        return;
    }
}

void CameraManager::iniciarCamaraSiHayPermiso() {
    QCameraPermission permiso;
    if (qApp->checkPermission(permiso) !=
        Qt::PermissionStatus::Granted) {
        emit statusError(tr("Cámara: no se puede iniciar (sin permiso)"));
        return;
    }
    const auto cams = QMediaDevices::videoInputs();
    if (cams.isEmpty()) {
        emit statusError(tr("Cámara: no hay dispositivos disponibles"));
        return;
    }
    const QCameraDevice dev = cams.front();
    m_camera = std::make_unique<QCamera>(dev);
    // Configuración de formatos y conexiones
    QCameraFormat chosen = pickFormat16x9(dev);
    if (chosen.isNull()) {
        // Fallback a 640x480 si no hay formato 16:9
        for (const auto &fmt : dev.videoFormats()) {
            const auto r = fmt.resolution();
            if (r.width()==640 && r.height()==480
                && fmt.maxFrameRate()>=30.0) {
                chosen = fmt; break;
            }
        }
    }
    if (!chosen.isNull()) m_camera->setCameraFormat(chosen);
    // Configuración del pipeline de video
    if (!m_sink) m_sink = std::make_unique<QVideoSink>();
    if (!m_sinkConnected) {
        connect(m_sink.get(), &QVideoSink::videoFrameChanged, this,
                [this](const QVideoFrame &f) {
                    if (!f.isValid()) return;
                    emit videoFrame(f);
                }, Qt::QueuedConnection);
        m_sinkConnected = true;
    }
    m_session.setVideoSink(m_sink.get());
    m_session.setCamera(m_camera.get());
    emit statusOk(tr("Iniciando cámara..."));
    m_camera->start();
}
