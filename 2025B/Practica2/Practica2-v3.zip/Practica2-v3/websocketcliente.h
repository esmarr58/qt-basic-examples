#pragma once
#include <QObject>
#include <QUrl>
#include <QJsonObject>
#include <QWebSocket>
#include <QTimer>
#include <QAbstractSocket>

class WebSocketCliente : public QObject
{
    Q_OBJECT
public:
    explicit WebSocketCliente(QObject* parent = nullptr);
    // Configuración/Control de sesión
    void setUrl(const QUrl& url);   // Se configura desde MainWindow
    void conectar();                // Usa m_url ya configurada
    void cerrar();

    // Heartbeat: envía {"tipo":"latido"} cada ms; 0 = desactiva
    void setHeartbeatInterval(int ms);
    // API de control (ajustada al servidor ESP32)
    // mover: accion = "avanzar" | "retroceder" | "izquierda" | "derecha" | "parar"
    void mover(const QString& accion, uint32_t ms = 600);
    void setRGB(int r, int g, int b);            // 0..255
    void setLED(bool encendido);                 // true/false
    void pedirDHT();                             // solicita lectura DHT

    // Envío genérico (por si lo necesitas)
    void enviarJson(const QJsonObject& obj);
signals:
    // Estado base
    void conectado();
    void desconectado();
    void estadoCambiado(QAbstractSocket::SocketState state);
    void errorTexto(QString descripcion);

    // Mensajería cruda
    void mensajeJsonRecibido(QJsonObject obj);

    // Eventos de alto nivel (según "tipo" del servidor)
    void saludoRecibido(QJsonObject saludo);     // "saludo" inicial del server
    void latidoOk(uint32_t tiempo_ms);           // "latido_ok"
    void dhtLectura(bool ok, double tempC, double hum);
    void ledAck(bool estado);
    void rgbAck(int r, int g, int b);
    void moverAck(QString accion, uint32_t ms);
    void moverErr(QString accion, uint32_t ms);
    void telemetria(QJsonObject payload);        // "telemetria"

private slots:
    void onConnected();
    void onDisconnected();
    void onTextMessageReceived(const QString& msg);
    void onErrorOccurred(QAbstractSocket::SocketError code);
    void onStateChanged(QAbstractSocket::SocketState s);
    void onHeartbeatTick();
private:
    void enviarJson_(const QJsonObject& obj); // wrapper interno

private:
    QWebSocket m_ws;
    QUrl       m_url;
    QTimer*    m_heartbeat = nullptr;
};
