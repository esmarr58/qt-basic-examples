#include "detectorcolores.h"
#include <opencv2/imgproc.hpp>
#include <QDebug>

DetectorColores::DetectorColores(QObject* parent)
    : QObject(parent)
{
}
void DetectorColores::setCoverageThreshold(double frac) {
    QMutexLocker lock(&m_mtx);
    if (frac < 0.0) frac = 0.0;
    if (frac > 1.0) frac = 1.0;
    m_coverageThresh = frac;
}

void DetectorColores::setActiveColorIndex(int idx) {
    QMutexLocker lock(&m_mtx);
    m_activeIdx = (idx == 2 ? 2 : 1);
}

void DetectorColores::setToleranciasHSV(int dH, int dS, int dV) {
    QMutexLocker lock(&m_mtx);
    m_dH = std::max(0, dH);
    m_dS = std::max(0, dS);
    m_dV = std::max(0, dV);
}

void DetectorColores::setRangoColor(int idx,
                                    int hMin, int sMin, int vMin,
                                    int hMax, int sMax, int vMax)
{
    QMutexLocker lock(&m_mtx);
    cv::Scalar lo(std::clamp(hMin, 0, 179),
                  std::clamp(sMin, 0, 255),
                  std::clamp(vMin, 0, 255));
    cv::Scalar hi(std::clamp(hMax, 0, 179),
                  std::clamp(sMax, 0, 255),
                  std::clamp(vMax, 0, 255));
    if (idx == 2) { m_low2 = lo; m_high2 = hi; m_has2 = true; }
    else          { m_low1 = lo; m_high1 = hi; m_has1 = true; }
    emit rangoActualizado(idx, (int)lo[0], (int)lo[1], (int)lo[2],
                          (int)hi[0], (int)hi[1], (int)hi[2]);
}

void DetectorColores::setCalibracionActiva(bool on) {
    QMutexLocker lock(&m_mtx);
    m_calibrando = on;
    emit estado(on ? QStringLiteral("Calibración: ON (haz clic en la imagen)")
                   : QStringLiteral("Calibración: OFF"));
}

bool DetectorColores::tieneColorCalibrado(int idx) const {
    QMutexLocker lock(&m_mtx);
    return (idx == 2) ? m_has2 : m_has1;
}

void DetectorColores::handleClickOnHSV(const QPoint& pos,
                                       const QImage& hsvImage)
{
    // Lee el HSV del pixel clicado para generar rango alrededor
    if (hsvImage.isNull()) return;
    if (pos.x() < 0 || pos.y() < 0 ||
        pos.x() >= hsvImage.width() ||
        pos.y() >= hsvImage.height()) return;
    // Esperamos QImage::Format_RGB888 (H,S,V) visualizado como 3 canales
    if (hsvImage.format() != QImage::Format_RGB888) {
        emit estado(QStringLiteral("Imagen HSV no está en Format_RGB888"));
        return;
    }

    const uchar* scan = hsvImage.constScanLine(pos.y());
    const uchar* px = scan + pos.x() * 3;

    int H = px[0]; // Nota: si tu conversión HSV->RGB888 reordena canales, ajustaremos
    int S = px[1];
    int V = px[2];
    // Guarda tolerancias
    int hMin = std::clamp(H - m_dH, 0, 179);
    int hMax = std::clamp(H + m_dH, 0, 179);
    int sMin = std::clamp(S - m_dS, 0, 255);
    int sMax = std::clamp(S + m_dS, 0, 255);
    int vMin = std::clamp(V - m_dV, 0, 255);
    int vMax = std::clamp(V + m_dV, 0, 255);

    setRangoColor(m_activeIdx, hMin, sMin, vMin, hMax, sMax, vMax);
    emit hsvLeido(H, S, V);
}

void DetectorColores::processFrame(const QImage& rgbaFrame)
{
    // Convierte RGBA -> HSV y aplica inRange para los dos colores
    if (rgbaFrame.isNull()) return;

    computeMasksFromRGBA(rgbaFrame);
}

void DetectorColores::computeMasksFromRGBA(const QImage& rgbaFrame)
{
    QImage frame = rgbaFrame.convertToFormat(QImage::Format_RGBA8888);
    cv::Mat mRGBA = qimageToMatRGBA(frame);

    cv::Mat mRGB, mHSV;
    cv::cvtColor(mRGBA, mRGB, cv::COLOR_RGBA2RGB);
    cv::cvtColor(mRGB,  mHSV, cv::COLOR_RGB2HSV);
    const int totalPix = mHSV.rows * mHSV.cols;
    if (totalPix <= 0) return;

    // Color 1
    if (m_has1) {
        cv::Mat mask1;
        cv::inRange(mHSV, m_low1, m_high1, mask1);
        const double coverage = (double)cv::countNonZero(mask1) / (double)totalPix;
        emit mascaraLista(1, matGrayToQImage(mask1), coverage);
        if (coverage >= m_coverageThresh) emit colorPredominante(1, coverage);
    }
    // Color 2
    if (m_has2) {
        cv::Mat mask2;
        cv::inRange(mHSV, m_low2, m_high2, mask2);
        const double coverage = (double)cv::countNonZero(mask2) / (double)totalPix;
        emit mascaraLista(2, matGrayToQImage(mask2), coverage);
        if (coverage >= m_coverageThresh) emit colorPredominante(2, coverage);
    }
}
cv::Mat DetectorColores::qimageToMatRGBA(const QImage& img)
{
    // QImage::Format_RGBA8888 -> CV_8UC4
    return cv::Mat(img.height(), img.width(), CV_8UC4,
                   const_cast<uchar*>(img.bits()),
                   img.bytesPerLine());
}

QImage DetectorColores::matGrayToQImage(const cv::Mat& m)
{
    // Esperamos 8UC1
    if (m.empty() || m.type() != CV_8UC1) return QImage();
    return QImage(m.data, m.cols, m.rows, static_cast<int>(m.step),
                  QImage::Format_Grayscale8).copy(); // copia segura
}

bool DetectorColores::getRangoColor(int idx, int& hMin,int& sMin,int& vMin,
                                    int& hMax,int& sMax,int& vMax) const
{
    QMutexLocker lock(&m_mtx);
    const bool ok = (idx == 2) ? m_has2 : m_has1;
    const cv::Scalar& lo = (idx == 2) ? m_low2  : m_low1;
    const cv::Scalar& hi = (idx == 2) ? m_high2 : m_high1;
    hMin = (int)lo[0]; sMin = (int)lo[1]; vMin = (int)lo[2];
    hMax = (int)hi[0]; sMax = (int)hi[1]; vMax = (int)hi[2];
    return ok;
}
