#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#pragma once
#include <QMainWindow>
#include <QThread>

#include <QLabel>

#include <QImage>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <atomic>

#include <QRect>
#include <QPainter>

#include <QMouseEvent>
#include <QSettings>
#include <QCloseEvent>

#include <QJsonObject>
#include <cmath>
#include <QStatusBar>

class WebSocketCliente;         // <-- forward-declare

class DetectorColores;   // ← Declaración adelantada

class FrameWorker;
class CameraManager;
class DetectorSonrisas;

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private slots:
    void onImageReady(const QImage &img);
    void setStatusOk(const QString &msg);
    void setStatusError(const QString &msg);

protected:
    bool eventFilter(QObject* obj, QEvent* event) override;
    void closeEvent(QCloseEvent* e) override;


private:
    Ui::MainWindow *ui;
    QThread m_workerThread;
    FrameWorker* m_worker = nullptr;

    CameraManager* m_cam = nullptr;
    QLabel *m_statusLbl = nullptr;

    std::atomic_bool m_busy{false};
    // Última imagen para repintar/resize
    QImage m_lastImg;
    QImage m_lastHSV; // HSV en QImage::Format_RGB888

    // Hilo y detector de sonrisas
    QThread m_hiloSonrisas;
    DetectorSonrisas* m_detector = nullptr;
    // Estado de detección para visualización
    QVector<QRect> m_rectsCaras;
    QVector<QRect> m_rectsSonrisas;
    bool m_hayCara = false;
    bool m_haySonrisa = false;

    QThread          m_colorThread;
    DetectorColores* m_color = nullptr;
    // Estado para dibujar y lógica de UI
    QImage m_maskColor1;   // máscara binaria color 1
    QImage m_maskColor2;   // máscara binaria color 2
    double m_cov1 = 0.0;   // cobertura [0..1] color 1
    double m_cov2 = 0.0;   // cobertura [0..1] color 2
    bool   m_pred1 = false; // color 1 predominante
    bool   m_pred2 = false; // color 2 predominante

    // Control de calibración
    bool m_calibrandoColor = false;
    int  m_colorActivo = 1;

    double m_colorThresh = 0.15;  // porcentaje mínimo

    QThread           m_wsThread;     // hilo donde correrá el cliente
    WebSocketCliente* m_ws = nullptr; // instancia que vivirá en m_wsThread
    QString ipESP32 = "esp32-5434e4.local";   // ← IP fija de ESP32

    // --- Control de comandos (anti-rebote + rate-limit + histéresis) ---
    enum class Accion { Parar, Avanzar, Retroceder, Izquierda, Derecha };

    Accion        m_lastAction      = Accion::Parar;
    int           m_sameActionFrames = 0;      // frames consecutivos con misma acción
    int           m_confirmFrames    = 3;      // N frames para confirmar antes de enviar
    int           m_minIntervalMs    = 200;    // rate-limit entre envíos de comandos
    QElapsedTimer m_actionTimer;                // cronómetro desde el último envío
};
#endif // MAINWINDOW_H
