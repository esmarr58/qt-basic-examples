// camera_manager.h
#pragma once
#include <QObject>
#include <QCamera>
#include <QMediaDevices>
#include <QMediaCaptureSession>
#include <QVideoSink>
#include <QPermission>
#include <QTimer>
class CameraManager : public QObject {
    Q_OBJECT
public:
    explicit CameraManager(QObject* parent=nullptr);
    ~CameraManager();
    // Arranca flujo completo: pide permisos y
    // si se conceden, inicia cámara
    void start();
signals:
    void videoFrame(const QVideoFrame& frame);
    void statusOk(const QString& msg);
    void statusError(const QString& msg);
private:
    static QCameraFormat pickFormat16x9(
        const QCameraDevice &dev);
    void pedirPermisosCamara();
    void iniciarCamaraSiHayPermiso();
    std::unique_ptr<QCamera> m_camera;
    std::unique_ptr<QVideoSink> m_sink;
    QMediaCaptureSession m_session;
    bool m_sinkConnected = false;
};
