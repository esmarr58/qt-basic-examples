#pragma once
#include <QObject>
#include <QImage>
#include <QRect>
#include <QVector>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/objdetect.hpp>
class DetectorSonrisas : public QObject {
    Q_OBJECT
public:
    explicit DetectorSonrisas(QObject *parent = nullptr);
    // Opcional: establecer ruta base manual
    Q_INVOKABLE void configurarRutaBase(const QString &rutaBase);
public slots:
    void procesar(const QImage &img);
signals:
    void resultado(bool hayCara, bool haySonrisa,
                   QVector<QRect> rectsCaras,
                   QVector<QRect> rectsSonrisas);
private:
    bool cargarModelos();
    bool cargarDesde(const QString &dir);
    static cv::Mat qimageToGray(const QImage &img);

private:
    cv::CascadeClassifier m_face;
    cv::CascadeClassifier m_smile;
    bool m_listos = false;
    QString m_rutaBase;
};
