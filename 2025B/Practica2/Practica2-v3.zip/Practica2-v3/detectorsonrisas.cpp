#include "detectorsonrisas.h"
#include <QFileInfo>
#include <QDir>
#include <QDebug>

DetectorSonrisas::DetectorSonrisas(QObject *parent)
    : QObject(parent) {
    m_listos = cargarModelos();
    if (!m_listos) {
        qWarning() << "[DetectorSonrisas] No se pudieron cargar los cascades.";
    }
}
void DetectorSonrisas::configurarRutaBase(const QString &rutaBase) {
    m_rutaBase = rutaBase;
    m_listos = cargarModelos();
}

bool DetectorSonrisas::cargarDesde(const QString &dir) {
    // Intenta default, si no existe prueba alt2
    const QString faceDef = QDir(dir).filePath("haarcascade_frontalface_default.xml");
    const QString faceAlt = QDir(dir).filePath("haarcascade_frontalface_alt2.xml");
    const QString smileFn = QDir(dir).filePath("haarcascade_smile.xml");
    QString faceFn;
    if (QFileInfo::exists(faceDef))      faceFn = faceDef;
    else if (QFileInfo::exists(faceAlt)) faceFn = faceAlt;
    else                                  return false;

    if (!QFileInfo::exists(smileFn)) return false;

    cv::CascadeClassifier face, smile;
    if (!face.load(faceFn.toStdString()))   return false;
    if (!smile.load(smileFn.toStdString())) return false;

    m_face = std::move(face);
    m_smile = std::move(smile);
    qDebug() << "[DetectorSonrisas] Cargados cascades desde:" << dir
             << " (face:" << QFileInfo(faceFn).fileName() << ")";
    return true;
}

bool DetectorSonrisas::cargarModelos() {
    // 1) Ruta base del usuario
    if (!m_rutaBase.isEmpty()) {
        if (cargarDesde(m_rutaBase)) return true;
    }

    // 2) OPENCV_DATA_DIR
    if (const QByteArray env = qgetenv("OPENCV_DATA_DIR"); !env.isEmpty()) {
        QString base = QString::fromLocal8Bit(env);
        if (cargarDesde(base)) return true;
        if (cargarDesde(QDir(base).filePath("haarcascades"))) return true;
    }
    // 3) Rutas típicas en Linux
    QStringList rutas = {
        "/usr/share/opencv4/haarcascades",
        "/usr/local/share/opencv4/haarcascades",
        "/usr/share/opencv/haarcascades",
        "/usr/local/share/opencv/haarcascades"
    };
    for (const auto &dir : rutas) {
        if (cargarDesde(dir)) return true;
    }
    return false;
}

cv::Mat DetectorSonrisas::qimageToGray(const QImage &img) {
    QImage gray = img.convertToFormat(QImage::Format_Grayscale8);
    return cv::Mat(gray.height(), gray.width(), CV_8UC1,
                   const_cast<uchar*>(gray.bits()), gray.bytesPerLine());
}

void DetectorSonrisas::procesar(const QImage &img) {
    if (!m_listos || img.isNull()) {
        emit resultado(false, false, {}, {});
        return;
    }

    // 1) Grises + equalize + leve blur
    cv::Mat gray = qimageToGray(img).clone();  // buffer propio
    cv::equalizeHist(gray, gray);
    cv::GaussianBlur(gray, gray, cv::Size(3,3), 0);

    // 2) Caras
    std::vector<cv::Rect> faces;
    m_face.detectMultiScale(gray, faces, 1.1, 4,
                            cv::CASCADE_SCALE_IMAGE,
                            cv::Size(80, 80)); // mínimo de cara razonable
    QVector<QRect> rectsCaras;
    rectsCaras.reserve(static_cast<int>(faces.size()));
    for (const auto &r : faces)
        rectsCaras.push_back(QRect(r.x, r.y, r.width, r.height));

    bool hayCara = !faces.empty();
    bool haySonrisa = false;
    QVector<QRect> rectsSmile;

    // 3) Sonrisa dentro de cada cara (ROI = parte inferior)
    for (const auto &fr : faces) {
        // ROI inferior (55% a 95% de alto de la cara)
        int top    = fr.y + static_cast<int>(fr.height * 0.55);
        int bottom = fr.y + static_cast<int>(fr.height * 0.95);
        top    = std::clamp(top, fr.y, fr.y + fr.height - 1);
        bottom = std::clamp(bottom, top + 1, fr.y + fr.height);
        cv::Rect mouthROI(fr.x, top, fr.width, bottom - top);
        // Tamaños mínimos/máximos relativos a la cara
        cv::Size minSz(std::max(25, fr.width/6),  std::max(15, fr.height/12));
        cv::Size maxSz(std::max(40, fr.width/2),  std::max(30, fr.height/3));

        std::vector<cv::Rect> smiles;
        m_smile.detectMultiScale(
            gray(mouthROI),
            smiles,
            1.75,            // scaleFactor más alto => más estricto
            32,              // minNeighbors alto => menos falsos positivos
            cv::CASCADE_SCALE_IMAGE,
            minSz,
            maxSz
            );

        // Filtros geométricos adicionales
        for (const auto &sr : smiles) {
            cv::Rect g(sr.x + mouthROI.x, sr.y + mouthROI.y, sr.width, sr.height);

            // Centro dentro del ancho de la cara y en la mitad inferior
            int cx = g.x + g.width/2;
            int cy = g.y + g.height/2;
            bool dentroAncho = (cx > fr.x + fr.width*0.15) &&
                               (cx < fr.x + fr.width*0.85);
            bool inferior    = (cy > fr.y + fr.height*0.55);

            // Tamaño razonable relativo a la cara
            bool tamañoOK =
                (g.width  > fr.width * 0.15) &&
                (g.width  < fr.width * 0.80) &&
                (g.height > fr.height* 0.08) &&
                (g.height < fr.height* 0.50);

            if (dentroAncho && inferior && tamañoOK) {
                rectsSmile.push_back(QRect(g.x, g.y, g.width, g.height));
            }
        }
    }

    if (!rectsSmile.isEmpty())
        haySonrisa = true;

    emit resultado(hayCara, haySonrisa, rectsCaras, rectsSmile);
}

