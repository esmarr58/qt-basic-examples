#include "vervideo.h"
#include <QPixmap>
#include <cmath> // std::abs
VerVideo::VerVideo(QWidget* parent)
    : QLabel(parent)
{
    setMinimumSize(160, 90);
    setSizePolicy(QSizePolicy::Expanding,
                  QSizePolicy::Expanding);
    setScaledContents(false);
    setAlignment(Qt::AlignCenter);
    setStyleSheet("background-color: black;");
}

void VerVideo::setImage(const QImage& img) {
    m_lastImg = img;
    updatePixmap();
}
void VerVideo::setAspect(double w, double h) {
    if (w > 0.0 && h > 0.0) {
        m_aspectW = w;
        m_aspectH = h;
        updatePixmap();
    }
}

void VerVideo::resizeEvent(QResizeEvent* e) {
    QLabel::resizeEvent(e);
    // Fuerza 16:9 (o el aspecto configurado)
    const int targetH = int(double(width()) *
                            m_aspectH / m_aspectW);
    if (std::abs(height() - targetH) > 1) {
        setFixedHeight(targetH);
    }
    updatePixmap();
}

void VerVideo::updatePixmap() {
    if (m_lastImg.isNull()) return;
    setPixmap(
        QPixmap::fromImage(m_lastImg).scaled(
            size(),
            Qt::KeepAspectRatio,
            Qt::SmoothTransformation
            )
        );
}
