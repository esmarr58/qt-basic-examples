#pragma once
#include <QLabel>
#include <QImage>
#include <QResizeEvent>
class VerVideo : public QLabel {
    Q_OBJECT
public:
    explicit VerVideo(QWidget* parent=nullptr);
    void setImage(const QImage& img);
    void setAspect(double w, double h); // por defecto 16:9
protected:
    void resizeEvent(QResizeEvent* e) override;
private:
    void updatePixmap();
    QImage m_lastImg;
    double m_aspectW = 16.0;
    double m_aspectH = 9.0;
};
