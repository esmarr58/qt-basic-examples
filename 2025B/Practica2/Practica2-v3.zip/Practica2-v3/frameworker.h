#pragma once
#include <QObject>
#include <QImage>
#include <QVideoFrame>
class FrameWorker : public QObject {
    Q_OBJECT
public:
    using QObject::QObject;
public slots:
    void process(const QVideoFrame &frame);
signals:
    void ready(const QImage &image);
};
