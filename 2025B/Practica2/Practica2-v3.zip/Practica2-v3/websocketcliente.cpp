#include "websocketcliente.h"
#include <QJsonDocument>
#include <QJsonParseError>
#include <QDebug>
#include <algorithm> // std::clamp

WebSocketCliente::WebSocketCliente(QObject* parent)
    : QObject(parent)
{
    // Asegura que m_ws sea hijo y se mueva de hilo junto con esta clase
    m_ws.setParent(this);
    // Crea el QTimer con parent=this para que SIGA a este objeto al moverlo de hilo
    m_heartbeat = new QTimer(this);
    m_heartbeat->setSingleShot(false);

    // Conexiones (igual que antes)
    connect(&m_ws, &QWebSocket::connected,    this, &WebSocketCliente::onConnected);
    connect(&m_ws, &QWebSocket::disconnected, this, &WebSocketCliente::onDisconnected);
    connect(&m_ws, &QWebSocket::textMessageReceived, this, &WebSocketCliente::onTextMessageReceived);
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
    connect(&m_ws, &QWebSocket::errorOccurred, this, &WebSocketCliente::onErrorOccurred);
#else
    connect(&m_ws, QOverload<QAbstractSocket::SocketError>::of(&QWebSocket::error),
            this, &WebSocketCliente::onErrorOccurred);
#endif
    connect(&m_ws, &QWebSocket::stateChanged, this, &WebSocketCliente::onStateChanged);

    connect(m_heartbeat, &QTimer::timeout, this, &WebSocketCliente::onHeartbeatTick);
}

void WebSocketCliente::setUrl(const QUrl& url) { m_url = url; }

void WebSocketCliente::conectar()
{
    if (!m_url.isValid()) {
        emit errorTexto(QStringLiteral("URL inválida para WebSocket"));
        return;
    }
    if (m_ws.state() != QAbstractSocket::UnconnectedState)
        m_ws.close();
    m_ws.open(m_url);
}

void WebSocketCliente::cerrar()
{
    if (m_ws.state() != QAbstractSocket::UnconnectedState)
        m_ws.close();
}

void WebSocketCliente::enviarJson(const QJsonObject& obj)
{
    enviarJson_(obj);
}
void WebSocketCliente::mover(const QString& accion, uint32_t ms)
{
    // Asegurar valores razonables: servidor limita a 8000 ms
    if (ms > 8000u) ms = 8000u;

    // Acciones válidas: avanzar/retroceder/izquierda/derecha/parar
    static const QStringList valid = { "avanzar","retroceder","izquierda","derecha","parar" };
    QString a = accion.toLower();
    if (!valid.contains(a)) a = "parar";
    QJsonObject obj{
        {"tipo",   "mover"},
        {"accion", a},
        {"ms",     static_cast<int>(ms)}
    };
    enviarJson_(obj);
}

void WebSocketCliente::setRGB(int r, int g, int b)
{
    r = std::clamp(r, 0, 255);
    g = std::clamp(g, 0, 255);
    b = std::clamp(b, 0, 255);
    QJsonObject obj{
        {"tipo","rgb"},
        {"r", r},
        {"g", g},
        {"b", b}
    };
    enviarJson_(obj);
}

void WebSocketCliente::setLED(bool encendido)
{
    QJsonObject obj{
        {"tipo","led"},
        {"estado", encendido ? 1 : 0}
    };
    enviarJson_(obj);
}

void WebSocketCliente::pedirDHT()
{
    QJsonObject obj{ {"tipo","leer_dht"} };
    enviarJson_(obj);
}

void WebSocketCliente::enviarJson_(const QJsonObject& obj)
{
    if (m_ws.state() == QAbstractSocket::ConnectedState) {
        const QByteArray payload = QJsonDocument(obj).toJson(QJsonDocument::Compact);
        m_ws.sendTextMessage(QString::fromUtf8(payload));
    } else {
        emit errorTexto(QStringLiteral("WS no conectado; no se envió JSON"));
    }
}
void WebSocketCliente::onConnected()
{
    emit conectado();
    if (m_heartbeat && m_heartbeat->isActive())
        onHeartbeatTick();
}

void WebSocketCliente::onDisconnected()
{
    emit desconectado();
}

void WebSocketCliente::onTextMessageReceived(const QString& msg)
{
    QJsonParseError perr;
    const QJsonDocument doc = QJsonDocument::fromJson(msg.toUtf8(), &perr);
    if (perr.error != QJsonParseError::NoError || !doc.isObject()) {
        emit errorTexto(QStringLiteral("Mensaje no-JSON o inválido: %1").arg(perr.errorString()));
        return;
    }
    const QJsonObject obj = doc.object();
    emit mensajeJsonRecibido(obj);

    const QString tipo = obj.value("tipo").toString();

    if (tipo == "saludo") {
        // {"tipo":"saludo", "mensaje":"...", "puerto":81, "nombre_host":"...", "mac":"..."}
        emit saludoRecibido(obj);
    }
    else if (tipo == "latido_ok") {
        const uint32_t t = obj.value("tiempo_ms").toInt(0);
        emit latidoOk(t);
    }
    else if (tipo == "dht_lectura") {
        const bool ok  = obj.value("dht_ok").toBool(false);
        const double T = obj.value("temperatura").toDouble(qQNaN());
        const double H = obj.value("humedad").toDouble(qQNaN());
        emit dhtLectura(ok, T, H);
    }
    else if (tipo == "led_ack") {
        const bool est = obj.value("estado").toInt(0) != 0;
        emit ledAck(est);
    }
    else if (tipo == "rgb_ack") {
        const int r = obj.value("r").toInt(0);
        const int g = obj.value("g").toInt(0);
        const int b = obj.value("b").toInt(0);
        emit rgbAck(r,g,b);
    }
    else if (tipo == "mover_ack" || tipo == "mover_err") {
        const QString accion = obj.value("accion").toString();
        const uint32_t ms    = static_cast<uint32_t>(obj.value("ms").toInt(0));
        if (tipo == "mover_ack") emit moverAck(accion, ms);
        else                     emit moverErr(accion, ms);
    }
    else if (tipo == "telemetria") {
        emit telemetria(obj);
    }
    // Ignora otros tipos silenciosamente (o emite mensajeJsonRecibido ya emitido)
}

void WebSocketCliente::onErrorOccurred(QAbstractSocket::SocketError)
{
    emit errorTexto(m_ws.errorString());
}

void WebSocketCliente::onStateChanged(QAbstractSocket::SocketState s)
{
    emit estadoCambiado(s);
}

void WebSocketCliente::setHeartbeatInterval(int ms)
{
    if (!m_heartbeat) return;
    if (ms > 0) m_heartbeat->start(ms);
    else        m_heartbeat->stop();
}

void WebSocketCliente::onHeartbeatTick()
{
    if (m_ws.state() == QAbstractSocket::ConnectedState)
        enviarJson_(QJsonObject{{"tipo","latido"}});
}
