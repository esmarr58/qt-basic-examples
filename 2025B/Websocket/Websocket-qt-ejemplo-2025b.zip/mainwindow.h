#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWebSocket>
#include <QTimer>
#include <QUrl>          // <-- Necesario porque usamos QUrl en el header

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Flujo WS
    void onConnected();
    void onDisconnected();
    void onTextMessageReceived(const QString &message);
    void onError(QAbstractSocket::SocketError error);
    void tryReconnect();
    void sendMessage();

    // === NUEVO: Keep-alive y seguimiento de estado ===
    void sendPing();                                        // envía ping periódico
    void onPong(quint64 elapsedTime, const QByteArray &payload); // recibe pong
    void onStateChanged(QAbstractSocket::SocketState s);    // log/acciones ante cambios

private:
    Ui::MainWindow *ui;
    QWebSocket *m_webSocket;
    QTimer m_reconnectTimer;   // reintentos programados
    QTimer m_pingTimer;        // <-- NUEVO: timer de keep-alive (ping)
    QUrl m_url;                // ws://esp32-xxxxxx.local:81 o ws://<IP>:81

    // === NUEVO: parámetros para backoff exponencial con jitter ===
    int    m_backoffMs = 2000;        // backoff inicial (2s)
    const  int m_backoffMaxMs = 30000; // máximo (30s)
    int    m_consecutiveFailures = 0;  // fallos consecutivos para escalar backoff
    qint64 m_lastPongMs = 0;           // último PONG recibido (ms desde epoch)

    void openSocket();
};

#endif // MAINWINDOW_H
