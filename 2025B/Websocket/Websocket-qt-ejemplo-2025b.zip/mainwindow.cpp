#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QDateTime>
#include <QRandomGenerator>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_webSocket(new QWebSocket)
{
    ui->setupUi(this);

    // 1) Ajusta aquí la URL (usa IP o mDNS)
    // m_url = QUrl(QStringLiteral("ws://esp32-123abc.local:81"));
    m_url = QUrl(QStringLiteral("ws://esp32-5434e4.local:81"));

    ui->textEdit->setReadOnly(true);

    // === Conexiones del WebSocket ===
    connect(m_webSocket, &QWebSocket::connected,
            this, &MainWindow::onConnected);
    connect(m_webSocket, &QWebSocket::disconnected,
            this, &MainWindow::onDisconnected);
    connect(m_webSocket, &QWebSocket::textMessageReceived,
            this, &MainWindow::onTextMessageReceived);
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    connect(m_webSocket, &QWebSocket::errorOccurred,
            this, &MainWindow::onError);
#else
    connect(m_webSocket, QOverload<QAbstractSocket::SocketError>::of(&QWebSocket::error),
            this, &MainWindow::onError);
#endif
    // NUEVOS: detectar ping/pong y cambios de estado
    connect(m_webSocket, &QWebSocket::pong, this, &MainWindow::onPong);
    connect(m_webSocket, &QWebSocket::stateChanged, this, &MainWindow::onStateChanged);

    // === Botón Enviar ===
    connect(ui->pushButton, &QPushButton::clicked,
            this, &MainWindow::sendMessage);

    // === Timer de reconexión (backoff variable) ===
    m_reconnectTimer.setSingleShot(true);
    connect(&m_reconnectTimer, &QTimer::timeout,
            this, &MainWindow::tryReconnect);

    // === Timer de keep-alive (ping/pong) ===
    m_pingTimer.setInterval(5000); // ping cada 5s
    connect(&m_pingTimer, &QTimer::timeout,
            this, &MainWindow::sendPing);

    openSocket();
}

MainWindow::~MainWindow() {
    if (m_webSocket) {
        m_webSocket->close();
        delete m_webSocket;
    }
    delete ui;
}

void MainWindow::openSocket() {
    ui->textEdit->append("Conectando a: " + m_url.toString());
    m_webSocket->open(m_url);
}

void MainWindow::onConnected() {
    ui->textEdit->append("Conectado al servidor WebSocket.");
    qDebug() << "Conectado:" << m_url;

    // Reinicia los contadores de backoff
    m_consecutiveFailures = 0;
    m_backoffMs = 2000;
    m_reconnectTimer.stop();

    // Enviar “latido” para que la ESP32 empiece a transmitir telemetría
    QJsonObject obj;
    obj["tipo"] = "latido";
    const QString json = QString::fromUtf8(
        QJsonDocument(obj).toJson(QJsonDocument::Compact));
    m_webSocket->sendTextMessage(json);
    ui->textEdit->append("TX: " + json);

    // Inicia el keep-alive
    m_lastPongMs = QDateTime::currentMSecsSinceEpoch();
    m_pingTimer.start();
}

void MainWindow::onDisconnected() {
    ui->textEdit->append("Desconectado del servidor WebSocket.");
    m_pingTimer.stop();

    // backoff exponencial con jitter
    if (!m_reconnectTimer.isActive()) {
        m_consecutiveFailures++;
        if (m_consecutiveFailures > 1)
            m_backoffMs = qMin(m_backoffMaxMs, m_backoffMs * 2);
        int jitter = QRandomGenerator::global()->bounded(0, 501);
        int delayMs = qMin(m_backoffMaxMs, m_backoffMs + jitter);
        ui->textEdit->append(QString("Reintentando en %1 ms...").arg(delayMs));
        m_reconnectTimer.start(delayMs);
    }
}

void MainWindow::onTextMessageReceived(const QString &message) {
    ui->textEdit->append("RX: " + message);

    const QJsonDocument doc = QJsonDocument::fromJson(message.toUtf8());
    if (!doc.isNull() && doc.isObject()) {
        const QJsonObject o = doc.object();
        const QString tipo = o.value("tipo").toString();
        if (tipo == "telemetria") {
            const int adc = o.value("adc").toInt();
            const double temp = o.value("temperatura").toDouble();
            const double hum  = o.value("humedad").toDouble();
            ui->textEdit->append(
                QString("Telemetría → ADC:%1  Temp:%2 °C  Hum:%3 %")
                    .arg(adc)
                    .arg(temp, 0, 'f', 2)
                    .arg(hum,  0, 'f', 2)
                );
        }
    }
}

void MainWindow::sendMessage() {
    const QString texto = ui->lineEdit->text().trimmed();
    if (texto.isEmpty()) return;

    QJsonParseError perr;
    const QJsonDocument doc = QJsonDocument::fromJson(texto.toUtf8(), &perr);

    if (perr.error == QJsonParseError::NoError && !doc.isNull()) {
        const QString json = QString::fromUtf8(doc.toJson(QJsonDocument::Compact));
        m_webSocket->sendTextMessage(json);
        ui->textEdit->append("TX (raw): " + json);
    } else {
        QJsonObject datos;
        datos["texto"]  = texto;
        datos["cuando"] = QDateTime::currentDateTime().toString(Qt::ISODate);

        QJsonObject obj;
        obj["tipo"]  = "eco";
        obj["datos"] = datos;

        const QString json = QString::fromUtf8(QJsonDocument(obj).toJson(QJsonDocument::Compact));
        m_webSocket->sendTextMessage(json);
        ui->textEdit->append("TX (eco): " + json);
    }

    ui->lineEdit->clear();
}

void MainWindow::onError(QAbstractSocket::SocketError) {
    const QString errStr = m_webSocket->errorString();
    ui->textEdit->append("Error WebSocket: " + errStr);

    // Cierra y programa reintento con backoff
    m_webSocket->abort();
    if (!m_reconnectTimer.isActive()) {
        m_consecutiveFailures++;
        if (m_consecutiveFailures > 1)
            m_backoffMs = qMin(m_backoffMaxMs, m_backoffMs * 2);
        int jitter = QRandomGenerator::global()->bounded(0, 501);
        int delayMs = qMin(m_backoffMaxMs, m_backoffMs + jitter);
        ui->textEdit->append(QString("Reintentando en %1 ms (por error)...").arg(delayMs));
        m_reconnectTimer.start(delayMs);
    }
}

void MainWindow::tryReconnect() {
    if (m_webSocket->state() == QAbstractSocket::UnconnectedState) {
        ui->textEdit->append("Reintentando conexión...");
        openSocket();
    } else {
        ui->textEdit->append("Forzando reinicio de socket...");
        m_webSocket->abort();
        openSocket();
    }
}

// === NUEVO: Keep-alive ===
void MainWindow::sendPing() {
    if (!m_webSocket) return;

    const qint64 ahora = QDateTime::currentMSecsSinceEpoch();
    const qint64 msDesdePong = ahora - m_lastPongMs;
    const qint64 timeoutPongMs = 12000; // 12s sin PONG → reinicio

    if (msDesdePong > timeoutPongMs) {
        ui->textEdit->append("No se recibió PONG a tiempo. Reiniciando conexión...");
        m_pingTimer.stop();
        m_webSocket->abort();
        onDisconnected();
        return;
    }

    m_webSocket->ping("keepalive");
}

void MainWindow::onPong(quint64 elapsedTime, const QByteArray &payload) {
    Q_UNUSED(payload);
    m_lastPongMs = QDateTime::currentMSecsSinceEpoch();
    ui->textEdit->append(QString("PONG (%1 ms)").arg(elapsedTime));
}

void MainWindow::onStateChanged(QAbstractSocket::SocketState s) {
    qDebug() << "Estado WebSocket:" << s;
}
