#include "detectordedos.h"
#include <QDebug>

DetectorDedos::DetectorDedos(QObject *parent) : QObject(parent) {}

cv::Mat DetectorDedos::qimageToBGR(const QImage &imgQ)
{
    QImage img = imgQ;
    if (img.format() != QImage::Format_RGB888)
        img = img.convertToFormat(QImage::Format_RGB888);
    cv::Mat rgb(img.height(), img.width(), CV_8UC3,
                const_cast<uchar*>(img.bits()), img.bytesPerLine());
    cv::Mat bgr; cv::cvtColor(rgb, bgr, cv::COLOR_RGB2BGR);
    return bgr;
}

// ángulo ABC (en grados) con B como vértice
double DetectorDedos::angleBetween(const cv::Point& A, const cv::Point& B, const cv::Point& C)
{
    cv::Point2f BA = cv::Point2f(A.x - B.x, A.y - B.y);
    cv::Point2f BC = cv::Point2f(C.x - B.x, C.y - B.y);
    double dot = BA.x*BC.x + BA.y*BC.y;
    double na = std::sqrt(BA.x*BA.x + BA.y*BA.y);
    double nb = std::sqrt(BC.x*BC.x + BC.y*BC.y);
    double cosang = (na > 1e-6 && nb > 1e-6) ? dot / (na*nb) : 1.0;
    cosang = std::clamp(cosang, -1.0, 1.0);
    return std::acos(cosang) * 180.0 / CV_PI;
}

void DetectorDedos::procesar(const QImage &imgQ)
{
    if (imgQ.isNull()) { emit resultado(0, {}, {}); return; }

    // ---- 1) Pre: BGR -> HSV y segmentación de piel
    cv::Mat bgr = qimageToBGR(imgQ);
    cv::Mat hsv; cv::cvtColor(bgr, hsv, cv::COLOR_BGR2HSV);

    // Rangos típicos de piel (puedes ajustar según iluminación)
    // Rango 1
    cv::Scalar low1(0,   30,  60);
    cv::Scalar high1(25, 170, 255);
    // Rango 2 (rojo que cruza el 180)
    cv::Scalar low2(160, 30,  60);
    cv::Scalar high2(180,170, 255);

    cv::Mat mask1, mask2, mask;
    cv::inRange(hsv, low1, high1, mask1);
    cv::inRange(hsv, low2, high2, mask2);
    mask = mask1 | mask2;

    // Suavizados y morfología
    cv::GaussianBlur(mask, mask, cv::Size(5,5), 0);
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN,  cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3,3)));
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7,7)));

    // ---- 2) Contornos y selección del mayor
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    if (contours.empty()) { emit resultado(0, {}, {}); return; }

    size_t idxMax = 0;
    double maxArea = 0.0;
    for (size_t i=0; i<contours.size(); ++i) {
        double a = cv::contourArea(contours[i]);
        if (a > maxArea) { maxArea = a; idxMax = i; }
    }
    if (maxArea < m_minAreaContour) { emit resultado(0, {}, {}); return; }

    const auto &hand = contours[idxMax];
    cv::Rect bbox = cv::boundingRect(hand);

    // ---- 3) Convex Hull + Convexity Defects
    std::vector<int> hullIdx;
    cv::convexHull(hand, hullIdx, false, false);
    if (hullIdx.size() < 3) { emit resultado(0, {}, {}); return; }

    std::vector<cv::Vec4i> defects;
    cv::convexityDefects(hand, hullIdx, defects);

    // Centro aproximado de la mano (centroide contorno)
    cv::Moments m = cv::moments(hand);
    cv::Point2f centro(
        (m.m00 != 0.0) ? static_cast<float>(m.m10 / m.m00) : (bbox.x + bbox.width*0.5f),
        (m.m00 != 0.0) ? static_cast<float>(m.m01 / m.m00) : (bbox.y + bbox.height*0.5f)
        );

    // ---- 4) Filtrar defectos para estimar puntas de dedos
    QVector<QPoint> fingertips;
    for (const auto &d : defects) {
        int iStart = d[0], iEnd = d[1], iFar = d[2];
        float depth = d[3] / 256.0f; // OpenCV almacena profundidad*256

        cv::Point pStart = hand[ iStart ];
        cv::Point pEnd   = hand[ iEnd   ];
        cv::Point pFar   = hand[ iFar   ];

        // Criterios: suficiente profundidad (valle), ángulo agudo en la punta
        if (depth < m_defectDepthThresh) continue;

        double ang = angleBetween(pStart, pFar, pEnd); // ángulo en el valle
        // Dedo = valle agudo y la punta está alrededor de pStart/pEnd arriba del centro
        if (ang > m_angleMaxDeg) continue;

        // Seleccionar posibles puntas: pStart y pEnd (más estables que 'far')
        // Además, deben estar por encima (menor y) que el centro de la palma
        if (pStart.y < centro.y)
            fingertips.push_back(QPoint(pStart.x, pStart.y));
        if (pEnd.y < centro.y)
            fingertips.push_back(QPoint(pEnd.x, pEnd.y));
    }

    // ---- 5) Depurar puntos repetidos (merge cercanos)
    auto dist2 = [](const QPoint& a, const QPoint& b){
        const int dx = a.x()-b.x(), dy=a.y()-b.y(); return dx*dx+dy*dy;
    };
    QVector<QPoint> tipsDepurados;
    const int minDist2 = 20*20; // 20 px
    for (const auto &p : fingertips) {
        bool cerca = false;
        for (const auto &q : tipsDepurados) {
            if (dist2(p,q) < minDist2) { cerca = true; break; }
        }
        if (!cerca) tipsDepurados.push_back(p);
    }

    // Limitar a 5
    while (tipsDepurados.size() > 5)
        tipsDepurados.removeLast();

    int dedos = tipsDepurados.size();
    if (dedos < 0) dedos = 0;
    if (dedos > 5) dedos = 5;

    emit resultado(dedos, tipsDepurados, QRect(bbox.x, bbox.y, bbox.width, bbox.height));
}
