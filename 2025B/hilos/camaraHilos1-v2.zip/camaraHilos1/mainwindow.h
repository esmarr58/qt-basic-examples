#pragma once
#include <QMainWindow>
#include <QCamera>
#include <QMediaDevices>
#include <QMediaCaptureSession>
#include <QVideoSink>
#include <QThread>
#include <QImage>
#include <atomic>
#include <memory>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <QLabel>
#include <QMessageBox>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class FrameWorker;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    void pedirPermisosCamara();
    void iniciarCamaraSiHayPermiso();

    // Selección de formato 16:9 cercano a 1280x720 o 1920x1080
    static QCameraFormat pickFormat16x9(const QCameraDevice &dev);

private slots:
    void onImageReady(const QImage &img);

    void setStatusOk(const QString &msg);
    void setStatusError(const QString &msg);
private:
    Ui::MainWindow *ui = nullptr;
    QLabel *m_statusLbl = nullptr;


    // Cámara y multimedia (SIEMPRE en hilo GUI)
    std::unique_ptr<QCamera>     m_camera;
    std::unique_ptr<QVideoSink>  m_sink;
    QMediaCaptureSession         m_session;

    // Procesamiento en hilo propio
    QThread      m_workerThread;
    FrameWorker* m_worker = nullptr;

    // Control de backpressure
    std::atomic_bool m_busy{false};

    // Última imagen para repintar/resize
    QImage m_lastImg;

    // Para no reconectar múltiples veces el sink
    bool m_sinkConnected = false;
};
