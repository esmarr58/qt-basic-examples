#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "trabajador_timer.h"

#include <QCoreApplication>
#include <QPermission>
#include <QResizeEvent>
#include <QPixmap>
#include <QDebug>
#include <cmath>
#include <QStatusBar>
#include <QLabel>
#include <QTimer>
#include <vector>

// ---------- Selección de formato 16:9 (prioriza 1920x1080, luego 1280x720) ----------
static double scoreSize16x9(const QSize &r) {
    const int W = r.width(), H = r.height();
    const bool is16x9 = (std::abs(W*9 - H*16) <= 2);
    double base = is16x9 ? 0.0 : 1000.0;  // penaliza fuerte si no es 16:9
    // distancia a 1920x1080 (más cerca, mejor)
    double d = std::hypot(double(W - 1920), double(H - 1080));
    return base + d;
}

QCameraFormat MainWindow::pickFormat16x9(const QCameraDevice &dev) {
    QCameraFormat best;
    double bestScore = 1e18;
    for (const auto &fmt : dev.videoFormats()) {
        if (fmt.maxFrameRate() < 30.0) continue;        // pide >= 30fps
        double s = scoreSize16x9(fmt.resolution());
        if (s < bestScore) { bestScore = s; best = fmt; }
    }
    return best; // puede quedar nulo si no encuentra >=30fps 16:9
}

// ---------- Permisos ----------
void MainWindow::pedirPermisosCamara() {
    QCameraPermission permiso;
    switch (qApp->checkPermission(permiso)) {
    case Qt::PermissionStatus::Granted:
        qDebug() << "[Permisos] Cámara ya concedida";
        iniciarCamaraSiHayPermiso();
        return;
    case Qt::PermissionStatus::Denied:
        qDebug() << "[Permisos] Cámara denegada por el sistema";
        return;
    case Qt::PermissionStatus::Undetermined:
        qDebug() << "[Permisos] Solicitando permiso de cámara…";
        qApp->requestPermission(permiso, this, [this](const QPermission &p){
            if (p.status() == Qt::PermissionStatus::Granted) {
                qDebug() << "[Permisos] Cámara concedida (callback)";
                QMetaObject::invokeMethod(this, [this]{ iniciarCamaraSiHayPermiso(); },
                                          Qt::QueuedConnection);
            } else {
                qDebug() << "[Permisos] Cámara no concedida en callback";
            }
        });
        return;
    }
}

// ---------- Resize (escala manteniendo aspecto) ----------
void MainWindow::resizeEvent(QResizeEvent *e) {
    QMainWindow::resizeEvent(e);

    if (m_lastImg.isNull()) return;

    const int targetW = ui->label->width();
    const int targetH = qRound(double(targetW) * m_lastImg.height() / m_lastImg.width());
    ui->label->setFixedSize(targetW, targetH);

    ui->label->setPixmap(
        QPixmap::fromImage(m_lastImg).scaled(ui->label->size(),
                                             Qt::KeepAspectRatio,
                                             Qt::SmoothTransformation)
        );
}

// ---------- Arranque de cámara (GUI thread) ----------
void MainWindow::iniciarCamaraSiHayPermiso() {
    QCameraPermission permiso;
    if (qApp->checkPermission(permiso) != Qt::PermissionStatus::Granted) {
        qDebug() << "[Cámara] No se puede iniciar: permiso NO concedido";
        return;
    }

    const auto cams = QMediaDevices::videoInputs();
    if (cams.isEmpty()) {
        qDebug() << "[Cámara] No hay cámaras disponibles";
        return;
    }

    // Log de resoluciones soportadas (útil para depurar)
    for (const auto &cam : cams) {
        qDebug() << "[Cámara]" << cam.description();
        for (const auto &fmt : cam.videoFormats()) {
            const QSize res = fmt.resolution();
            qDebug() << "   Resolución:" << res.width() << "x" << res.height()
                     << "fps:" << fmt.minFrameRate() << "-" << fmt.maxFrameRate();
        }
    }

    // Toma la primera cámara (ajusta según descripción si requieres otra)
    const QCameraDevice dev = cams.front();
    m_camera = std::make_unique<QCamera>(dev);

    // *** Conectar errores AQUÍ (ya existe m_camera) ***
    connect(m_camera.get(), &QCamera::errorOccurred, this,
            [this](QCamera::Error e, const QString &s){
                qDebug() << "[Cámara][error]" << e << s;

                const QString msg = s.isEmpty()
                                        ? tr("Error de cámara")
                                        : s;

                // Heurística: ocupado por otra app
                const QString lower = msg.toLower();
                const bool ocupado =
                    lower.contains("busy") ||
                    lower.contains("in use") ||
                    lower.contains("ocup") ||           // “ocupado”
                    lower.contains("device or resource busy");

                if (ocupado) {
                    setStatusError(tr("Cámara ocupada por otra aplicación"));
                    QMessageBox::critical(
                        this,
                        tr("Error de cámara"),
                        ocupado
                            ? tr("La cámara está ocupada por otra aplicación.\n\nCierra el otro programa y vuelve a intentarlo.")
                            : msg
                        );

                } else {
                    setStatusError(msg);
                }
            });

    // Estado activo/inactivo (no marcar activa si hay error)
    connect(m_camera.get(), &QCamera::activeChanged, this, [this](bool activa){
        if (activa && m_camera->error() == QCamera::NoError) {
            setStatusOk(tr("Cámara activa"));
        } else if (!activa) {
            setStatusError(tr("Cámara no activa"));
        }
    });

    // Elige 16:9 “cercano” a 1920x1080/1280x720 (>=30fps)
    QCameraFormat chosen = pickFormat16x9(dev);

    // (Fallback opcional) si no hay 16:9 a 30fps, podrías elegir 640x480@30fps
    if (chosen.isNull()) {
        for (const auto &fmt : dev.videoFormats()) {
            const auto r = fmt.resolution();
            if (r.width() == 640 && r.height() == 480 && fmt.maxFrameRate() >= 30.0) {
                chosen = fmt;
                break;
            }
        }
    }

    if (!chosen.isNull()) {
        m_camera->setCameraFormat(chosen);
        qDebug() << "[Cam] usando" << chosen.resolution() << "@"
                 << chosen.maxFrameRate() << "fps";
    } else {
        qDebug() << "[Cam] no se encontró formato deseado; usando default del backend";
    }

    // Crear sink (GUI thread)
    if (!m_sink) m_sink = std::make_unique<QVideoSink>();

    // Bandera local para detectar primer frame
    static bool s_gotFirstFrame = false;
    s_gotFirstFrame = false;

    // Conectar UNA vez: GUI -> worker (dropear si ocupado)
    if (!m_sinkConnected) {
        connect(m_sink.get(), &QVideoSink::videoFrameChanged, this,
                [this](const QVideoFrame &f) {
                    if (!f.isValid()) return;
                    if (!m_lastImg.isNull() == false && !statusBar()->isHidden()) {
                        // nada
                    }
                    if (!s_gotFirstFrame) {
                        setStatusOk(tr("Recibiendo video"));
                        s_gotFirstFrame = true;
                    }

                    if (m_busy.exchange(true)) return;

                    QVideoFrame fcopy(f); // compatible Qt 6.2–6.9
                    QMetaObject::invokeMethod(m_worker, [this, fcopy]{
                        m_worker->process(fcopy);
                    }, Qt::QueuedConnection);
                },
                Qt::QueuedConnection);

        m_sinkConnected = true;
    }

    // Orden correcto: primero sink, luego cámara, luego start()
    m_session.setVideoSink(m_sink.get());
    m_session.setCamera(m_camera.get());

    qDebug() << "[Cámara] start()";
    setStatusOk(tr("Iniciando cámara…"));
    m_camera->start();

    // Watchdog: si no hay frames tras 1200 ms y no hay error explícito, avisa
    QTimer::singleShot(1200, this, [this]{
        if (m_lastImg.isNull() && m_camera && m_camera->error() == QCamera::NoError) {
            setStatusError(tr("Sin señal de video"));
        }
    });
}

// ---------- Callback: imagen lista desde el worker (GUI thread) ----------
void MainWindow::onImageReady(const QImage &img)
{
    m_lastImg = img;
    if (m_lastImg.isNull()) { m_busy = false; return; }

    // === Tu procesamiento (gris/HSV) se queda igual ===
    QImage qrgba = m_lastImg.convertToFormat(QImage::Format_RGBA8888);
    cv::Mat rgba(qrgba.height(), qrgba.width(), CV_8UC4,
                 const_cast<uchar*>(qrgba.bits()), qrgba.bytesPerLine());

    QImage toShow;
    if (ui->checkBox->isChecked()) {
        cv::Mat gray; cv::cvtColor(rgba, gray, cv::COLOR_RGBA2GRAY);
        toShow = QImage(gray.data, gray.cols, gray.rows,
                        (int)gray.step, QImage::Format_Grayscale8).copy();
    } else {
        cv::Mat rgb, hsv;
        cv::cvtColor(rgba, rgb, cv::COLOR_RGBA2RGB);
        cv::cvtColor(rgb, hsv, cv::COLOR_RGB2HSV);

        std::vector<cv::Mat> ch; cv::split(hsv, ch);
        cv::Mat fullS(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));
        cv::Mat fullV(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));
        cv::Mat hsvVis; cv::merge(std::vector<cv::Mat>{ ch[0], fullS, fullV }, hsvVis);

        cv::Mat rgbVis; cv::cvtColor(hsvVis, rgbVis, cv::COLOR_HSV2RGB);
        toShow = QImage(rgbVis.data, rgbVis.cols, rgbVis.rows,
                        (int)rgbVis.step, QImage::Format_RGB888).copy();
    }

    // === Pintado (sin setFixedSize) ===
    const int w = ui->label->width();
    const int h = ui->label->height();
    const int targetW = (w > 0 ? w : toShow.width());
    const int targetH = (h > 0 ? h : toShow.height());

    ui->label->setPixmap(
        QPixmap::fromImage(toShow).scaled(
            QSize(targetW, targetH),
            Qt::KeepAspectRatio,
            Qt::SmoothTransformation
            )
        );

    m_busy = false;
}



// ---------- Ctor / Dtor ----------
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    ui->setupUi(this);

    m_statusLbl = new QLabel(this);
    m_statusLbl->setText(QString());                   // vacío
    m_statusLbl->setStyleSheet("color: #2e7d32;");     // verde por defecto (OK)
    statusBar()->addPermanentWidget(m_statusLbl, 1);

    // Worker en hilo propio (solo CPU, nada de GUI/GL aquí)
    m_worker = new FrameWorker();
    m_worker->moveToThread(&m_workerThread);
    connect(&m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    m_workerThread.start();

    // Worker -> GUI: pintar imagen
    connect(m_worker, &FrameWorker::ready, this, &MainWindow::onImageReady,
            Qt::QueuedConnection);

    // Pedir permisos y arrancar cámara si procede
    pedirPermisosCamara();

    // (OJO) no conectamos errorOccurred aquí; se conecta tras crear m_camera
}

MainWindow::~MainWindow() {
    m_workerThread.quit();
    m_workerThread.wait();
    delete ui;
}

void MainWindow::setStatusOk(const QString &msg) {
    m_statusLbl->setStyleSheet("color: #2e7d32; font-weight: 600;"); // verde
    m_statusLbl->setText(msg);
}

void MainWindow::setStatusError(const QString &msg) {
    m_statusLbl->setStyleSheet("color: #c62828; font-weight: 700;"); // rojo
    m_statusLbl->setText(msg);
}
