#include "trabajador_timer.h"

TrabajadorTimer::TrabajadorTimer(int intervaloMs, QObject *padre)
    : QObject(padre),
    temporizador(this),          // <-- clave: darle padre para que se mueva de hilo con el worker
    intervalo(intervaloMs)
{
    temporizador.setInterval(intervalo);
    temporizador.setTimerType(Qt::PreciseTimer);

    connect(&temporizador, &QTimer::timeout, this, [this]() {
        contador++;
        emit valorCambiado(contador);
    });
}

void TrabajadorTimer::iniciar() {
    temporizador.start();
}

void TrabajadorTimer::detener() {
    temporizador.stop();
}

void TrabajadorTimer::definirIntervalo(int ms) {
    intervalo = ms;
    temporizador.setInterval(intervalo);
}
