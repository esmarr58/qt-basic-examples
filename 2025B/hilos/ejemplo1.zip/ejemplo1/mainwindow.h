#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QThread>
#include "trabajador_timer.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QThread *hilo1 = nullptr;
    QThread *hilo2 = nullptr;

    TrabajadorTimer *trabajador1 = nullptr;
    TrabajadorTimer *trabajador2 = nullptr;
};
#endif // MAINWINDOW_H
