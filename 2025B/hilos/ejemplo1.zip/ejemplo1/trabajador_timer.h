#pragma once
#include <QObject>
#include <QTimer>

class TrabajadorTimer : public QObject {
    Q_OBJECT
public:
    explicit TrabajadorTimer(int intervaloMs = 1000, QObject *padre = nullptr);

public slots:
    void iniciar();
    void detener();
    void definirIntervalo(int ms);

signals:
    void valorCambiado(int valor);

private:
    QTimer temporizador;   // ahora tendrá padre = this
    int intervalo;
    int contador = 0;
};
