#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // ===== Hilo 1 y su trabajador =====
    hilo1 = new QThread(this);
    trabajador1 = new TrabajadorTimer(1000); // cada 1 segundo
    trabajador1->moveToThread(hilo1);

    // Importante: iniciar el temporizador por conexión encolada (en el hilo del trabajador)
    connect(hilo1, &QThread::started,
            trabajador1, &TrabajadorTimer::iniciar,
            Qt::QueuedConnection);

    // Cerrar limpio al salir de la app
    connect(qApp, &QCoreApplication::aboutToQuit, hilo1, &QThread::quit);

    // Actualizar UI desde el hilo principal (Qt hará queued connection entre hilos)
    connect(trabajador1, &TrabajadorTimer::valorCambiado, this, [this](int v) {
        ui->lcdNumber->display(v);
    });

    // Liberación cuando termine el hilo
    connect(hilo1, &QThread::finished, trabajador1, &QObject::deleteLater);

    hilo1->start();

    // ===== Hilo 2 y su trabajador =====
    hilo2 = new QThread(this);
    trabajador2 = new TrabajadorTimer(500); // cada 0.5 segundos
    trabajador2->moveToThread(hilo2);

    connect(hilo2, &QThread::started,
            trabajador2, &TrabajadorTimer::iniciar,
            Qt::QueuedConnection);

    connect(qApp, &QCoreApplication::aboutToQuit, hilo2, &QThread::quit);

    connect(trabajador2, &TrabajadorTimer::valorCambiado, this, [this](int v) {
        ui->lcdNumber_2->display(v);
    });

    connect(hilo2, &QThread::finished, trabajador2, &QObject::deleteLater);

    hilo2->start();


}

MainWindow::~MainWindow()
{
    if (hilo1) { hilo1->quit(); hilo1->wait(); }
    if (hilo2) { hilo2->quit(); hilo2->wait(); }

    delete ui;
}
