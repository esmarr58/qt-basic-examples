#pragma once
#include <QObject>
#include <QVideoFrame>
#include <QImage>

class FrameWorker : public QObject {
    Q_OBJECT
public slots:
    // Recibe un frame (desde QVideoSink) y lo procesa en este hilo
    void process(const QVideoFrame &frame);

signals:
    // Emite la imagen lista para pintar en la UI
    void ready(const QImage &img);
};
