#pragma once
#include <QMainWindow>
#include <QVideoFrame>
#include <QMediaCaptureSession>
#include <QCamera>
#include <QVideoSink>
#include <QMediaDevices>
#include <QCameraFormat>
#include <QThread>
#include <atomic>
#include <memory>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class FrameWorker; // forward

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void pedirPermisosCamara();

private slots:
    void onImageReady(const QImage &img); // NUEVO: pintar imagen

    void iniciarCamaraSiHayPermiso();
protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    Ui::MainWindow *ui;
    QImage m_lastImg;   // guarda el último frame para reescalar/redibujar

    QMediaCaptureSession m_session;
    std::unique_ptr<QCamera> m_camera;
    std::unique_ptr<QVideoSink> m_sink;

    // Worker + control de saturación
    QThread m_workerThread;
    FrameWorker* m_worker = nullptr;
    std::atomic_bool m_busy{false};
    bool m_sinkConnected = false; // evita conexiones duplicadas
};
