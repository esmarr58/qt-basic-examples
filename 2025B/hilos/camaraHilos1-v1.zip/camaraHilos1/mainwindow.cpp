#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "trabajador_timer.h"
#include <QPermission>
#include <QPixmap>
#include <QDebug>
#include <QPixmap>
#include <QImage>
#include <opencv2/imgproc.hpp>  // cv::cvtColor, cv::split, cv::merge

#include <QPermission>
#include <QCoreApplication> // para qApp

#include <QResizeEvent>  // asegúrate de tener este include

#include <QPermission>
#include <QCoreApplication> // qApp

void MainWindow::pedirPermisosCamara()
{
    QCameraPermission permiso;
    switch (qApp->checkPermission(permiso)) {
    case Qt::PermissionStatus::Granted:
        qDebug() << "[Permisos] Cámara ya concedida";
        iniciarCamaraSiHayPermiso();
        return;

    case Qt::PermissionStatus::Denied:
        qDebug() << "[Permisos] Cámara denegada por el sistema";
        return;

    case Qt::PermissionStatus::Undetermined:
        qDebug() << "[Permisos] Solicitando permiso de cámara…";
        qApp->requestPermission(permiso, this, [this](const QPermission &p){
            if (p.status() == Qt::PermissionStatus::Granted) {
                qDebug() << "[Permisos] Cámara concedida (callback)";
                QMetaObject::invokeMethod(this, [this]{
                    iniciarCamaraSiHayPermiso();
                }, Qt::QueuedConnection);
            } else {
                qDebug() << "[Permisos] Cámara no concedida en callback";
            }
        });
        return;
    }
}


void MainWindow::resizeEvent(QResizeEvent *e)
{
    QMainWindow::resizeEvent(e);  // llama al comportamiento base

    if (m_lastImg.isNull()) return;

    const int targetW = ui->label->width();
    const int targetH = qRound(double(targetW) * m_lastImg.height() / m_lastImg.width());
    ui->label->setFixedSize(targetW, targetH);

    QPixmap px = QPixmap::fromImage(m_lastImg);
    px.setDevicePixelRatio(1.0);

    ui->label->setPixmap(px.scaled(ui->label->size(),
                                   Qt::KeepAspectRatio,
                                   Qt::SmoothTransformation));
}


// --- Helper: elegir el mejor formato 16:9 (prioriza 1920x1080, luego 1280x720) ---
static QCameraFormat pickFormat16x9(const QCameraDevice &dev) {
    QCameraFormat best;
    double bestScore = 1e18;

    auto score = [](const QSize &r) -> double {
        const int W = r.width(), H = r.height();
        // ¿Es 16:9 (con tolerancia de 2 px por padding)?
        const bool is16x9 = (std::abs(W*9 - H*16) <= 2);
        // Penaliza fuerte si no es 16:9
        double base = is16x9 ? 0.0 : 1000.0;
        // Distancia euclídea a 1920x1080 (mientras más cerca, mejor)
        double d = std::hypot(double(W - 1920), double(H - 1080));
        return base + d;
    };

    for (const auto &fmt : dev.videoFormats()) {
        // nos quedamos con formatos que lleguen al menos a 30 fps máximos
        if (fmt.maxFrameRate() < 30.0)
            continue;
        const double s = score(fmt.resolution());
        if (s < bestScore) {
            bestScore = s;
            best = fmt;
        }
    }
    return best;
}

void MainWindow::iniciarCamaraSiHayPermiso()
{
    QCameraPermission permiso;
    if (qApp->checkPermission(permiso) != Qt::PermissionStatus::Granted) {
        qDebug() << "[Cámara] No se puede iniciar: permiso NO concedido";
        return;
    }

    const auto cams = QMediaDevices::videoInputs();
    if (cams.isEmpty()) {
        qDebug() << "[Cámara] No hay cámaras disponibles";
        return;
    }

    // Log de formatos disponibles (útil para depurar)
    for (const auto &cam : cams) {
        qDebug() << "[Cámara]" << cam.description();
        for (const auto &fmt : cam.videoFormats()) {
            const QSize res = fmt.resolution();
            qDebug() << "   Resolución:" << res.width() << "x" << res.height()
                     << "fps:" << fmt.minFrameRate() << "-" << fmt.maxFrameRate();
        }
    }

    // Crear cámara (elige la primera; puedes seleccionar por description si quieres la frontal)
    const QCameraDevice dev = cams.front();
    m_camera = std::make_unique<QCamera>(dev);

    // --- Elegir formato 16:9 “limpio” (evita 1088 alto y recortes) ---
    QCameraFormat chosen;


    if (chosen.isNull()) {
        // intenta 1280x720 explícito
        for (const auto &fmt : dev.videoFormats()) {
            const auto r = fmt.resolution();
            if (r.width() == 352 && r.height() == 288 && fmt.maxFrameRate() >= 30.0) {
                chosen = fmt; break;
            }
        }
    }

    if (!chosen.isNull()) {
        m_camera->setCameraFormat(chosen);
        qDebug() << "[Cam] usando" << chosen.resolution()
                 << "@" << chosen.maxFrameRate() << "fps";
    } else {
        qDebug() << "[Cam] no se encontró formato 16:9 >=30fps; usando default del backend";
    }

    // Crear sink si hace falta
    if (!m_sink)
        m_sink = std::make_unique<QVideoSink>();

    // Conectar UNA sola vez: worker + drop de frames si está ocupado
    if (!m_sinkConnected) {
        connect(
            m_sink.get(),
            &QVideoSink::videoFrameChanged,
            this,
            [this](const QVideoFrame &f) {
                if (m_busy.exchange(true)) return; // descarta si worker ocupado
                QMetaObject::invokeMethod(m_worker, [this, f]{
                    m_worker->process(f);          // conversión/rotación en el worker
                }, Qt::QueuedConnection);
            },
            Qt::QueuedConnection
            );
        m_sinkConnected = true;
    }

    // Orden estable
    m_session.setVideoSink(m_sink.get());
    m_session.setCamera(m_camera.get());

    connect(m_camera.get(), &QCamera::activeChanged, this, [](bool a){
        qDebug() << "[Cámara] activeChanged =" << a;
    });
    connect(m_camera.get(), &QCamera::errorOccurred, this,
            [](QCamera::Error e, const QString &s){
                qDebug() << "[Cámara][error]" << e << s;
            });

    qDebug() << "[Cámara] start()";
    m_camera->start();
}



void MainWindow::onImageReady(const QImage &img)
{
    m_lastImg = img;
    if (m_lastImg.isNull()) { m_busy = false; return; }

    // Trabajemos en RGBA coherente
    QImage qrgba = m_lastImg.convertToFormat(QImage::Format_RGBA8888);

    // QImage -> cv::Mat (RGBA)
    cv::Mat rgba(qrgba.height(), qrgba.width(), CV_8UC4,
                 const_cast<uchar*>(qrgba.bits()), qrgba.bytesPerLine());

    QImage toShow;

    if (ui->checkBox->isChecked()) {
        // ====== Grises ======
        cv::Mat gray;
        cv::cvtColor(rgba, gray, cv::COLOR_RGBA2GRAY);

        toShow = QImage(gray.data, gray.cols, gray.rows,
                        static_cast<int>(gray.step), QImage::Format_Grayscale8).copy();
    } else {
        // ====== Visualización HSV ======
        // 1) RGBA -> RGB
        cv::Mat rgb;
        cv::cvtColor(rgba, rgb, cv::COLOR_RGBA2RGB);

        // 2) RGB -> HSV
        cv::Mat hsv;
        cv::cvtColor(rgb, hsv, cv::COLOR_RGB2HSV);

        // 3) Usamos el canal H como matiz, con S=255, V=255 para "colorear" por tono
        std::vector<cv::Mat> ch;
        cv::split(hsv, ch); // ch[0]=H (0..179), ch[1]=S, ch[2]=V

        cv::Mat fullS(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));
        cv::Mat fullV(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));

        cv::Mat hsvVis;
        cv::merge(std::vector<cv::Mat>{ ch[0], fullS, fullV }, hsvVis);

        // 4) HSV -> RGB para poder mostrarlo
        cv::Mat rgbVis;
        cv::cvtColor(hsvVis, rgbVis, cv::COLOR_HSV2RGB);

        // 5) RGB -> QImage
        toShow = QImage(rgbVis.data, rgbVis.cols, rgbVis.rows,
                        static_cast<int>(rgbVis.step), QImage::Format_RGB888).copy();
    }

    // Mostrar (puedes escalar si quieres mantener proporción según el ancho actual)
    // Ejemplo: ajuste al ancho lógico del label manteniendo aspecto
    const int w = ui->label->width();
    const int h = qRound(double(w) * toShow.height() / toShow.width());

    ui->label->setScaledContents(false);
    ui->label->setAlignment(Qt::AlignCenter);
    ui->label->setFixedSize(w, h);

    ui->label->setPixmap(
        QPixmap::fromImage(toShow).scaled(ui->label->size(),
                                          Qt::KeepAspectRatio,
                                          Qt::SmoothTransformation)
        );

    m_busy = false;
}





MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // El label debe pintar ligero (sin centrado, auto-escala por GPU)
    //ui->label->setScaledContents(false);
    //ui->label->setAlignment(Qt::AlignLeft | Qt::AlignTop);

    // Worker en hilo propio
    m_worker = new FrameWorker();
    m_worker->moveToThread(&m_workerThread);
    connect(&m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    m_workerThread.start();

    // Worker -> UI: pintar imagen ya lista
    connect(m_worker, &FrameWorker::ready,
            this, &MainWindow::onImageReady,
            Qt::QueuedConnection);

    // Pide permisos (tu función actual)
    pedirPermisosCamara();
}

MainWindow::~MainWindow()
{
    m_workerThread.quit();
    m_workerThread.wait();
    delete ui;
}
