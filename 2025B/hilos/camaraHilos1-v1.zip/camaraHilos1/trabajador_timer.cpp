#include "trabajador_timer.h"
#include <QTransform>
#include <QDebug>
#include <opencv2/imgproc.hpp>

void FrameWorker::process(const QVideoFrame &frame) {
    if (!frame.isValid())
        return;

    QImage img = frame.toImage();
    if (img.isNull()) {
        qDebug() << "[FrameWorker] frame.toImage() nulo";
        return;
    }

#if QT_VERSION >= QT_VERSION_CHECK(6,6,0)
    const int angle = int(frame.rotation());
    if (angle) {
        QTransform t; t.rotate(angle);
        img = img.transformed(t);
    }
#endif

    // 🔹 Fuerza un formato estable: RGBA8888 (no premultiplicado)
    img = img.convertToFormat(QImage::Format_RGBA8888);

    // 🔹 QImage -> cv::Mat interpretándolo como RGBA
    cv::Mat rgba(img.height(), img.width(), CV_8UC4,
                 const_cast<uchar*>(img.bits()),
                 img.bytesPerLine());

    // (Opcional) resize con OpenCV
    // cv::Mat resizedRGBA;
    // cv::resize(rgba, resizedRGBA, cv::Size(1080, 720), 0, 0, cv::INTER_LINEAR);
    // const cv::Mat &out = resizedRGBA.empty() ? rgba : resizedRGBA;
    const cv::Mat &out = rgba; // si no quieres redimensionar aquí

    // 🔹 Volver a QImage interpretando RGBA8888 (coherente con lo anterior)
    QImage outImg(out.data, out.cols, out.rows, (int)out.step, QImage::Format_RGBA8888);

    // Copia profunda para que el buffer no dependa de 'out'
    QImage finalCopy = outImg.copy();

    emit ready(finalCopy);
}
